(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Wifi02svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#006D94").s().p("AAAAHQgaAAgTATIgWgXQAcgcAnAAQAoAAAcAcIgWAXQgTgTgbAAg");
	this.shape.setTransform(34.35,33.15,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AnLEYIAAovIOXAAIAAIvg");
	this.shape_1.setTransform(46,28);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,92,56);


(lib.Wifi04svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#006D94").s().p("ABLADQgkgOgnAAQgmAAgkAOQgjAPgbAaIgWgWQAfgeAogSQAqgRAtAAQAuAAAqARQAoASAfAeIgWAWQgbgagjgPg");
	this.shape.setTransform(34.35,11.15,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AnLEYIAAovIOXAAIAAIvg");
	this.shape_1.setTransform(46,28);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,92,56);


(lib.Wifi03svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#006D94").s().p("AAAgCQg0AAgmAlIgXgXQAWgVAdgNQAegMAgAAQBDAAAvAuIgXAXQgmglg1AAg");
	this.shape.setTransform(34.35,22.2,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AnLEYIAAovIOXAAIAAIvg");
	this.shape_1.setTransform(46,28);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,92,56);


(lib.Wifi01svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AAAAOIgtAvIgPgOIAvgvIgvguIAPgOIAtAvIAvgvIAOAOIgvAuIAvAvIgOAOg");
	this.shape.setTransform(77.25,41.65,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006D94").s().p("AgWAXQgJgKAAgNQAAgMAJgKQAKgJAMAAQANAAAKAJQAJAKAAAMQAAANgJAKQgKAJgNAAQgMAAgKgJg");
	this.shape_1.setTransform(34.35,47.35,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AnLEYIAAovIOXAAIAAIvg");
	this.shape_2.setTransform(46,28);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,92,56);


(lib.Uploadpropertiesrightsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AgdAKIAAgTIA7AAIAAATg");
	this.shape.setTransform(101,54.7,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AgdAKIAAgTIA7AAIAAATg");
	this.shape_1.setTransform(101,46.7,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgdAKIAAgTIA7AAIAAATg");
	this.shape_2.setTransform(101,38.7,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AhFBaIAAifIgKAAIAAgUICfAAIAAAUIgKAAIAACfgAgxBGIBjAAIAAiLIhjAAg");
	this.shape_3.setTransform(101,46.7,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_4.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Uploadpropertieslogosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AghBbIhqi1IBHAAIBGB6IAfg1IgfAAIgphFICzAAIhpC1g");
	this.shape.setTransform(64.95,38.65,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_1.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Uploadpropertiesleftsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape.setTransform(33,54.7,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_1.setTransform(25,54.7,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_2.setTransform(33,46.7,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_3.setTransform(25,46.7,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_4.setTransform(33,38.7,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_5.setTransform(25,38.7,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#101828").s().p("AhFBfIAAiyICLgMIAAC+gAgxhAIAACLIBjAAIAAiTg");
	this.shape_6.setTransform(29,45.6,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_7.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Uploadpropertiesdesktopsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("Ag1EMQgNAAgJgJQgJgKAAgNIANg2IjPAAQgRAAgNgNQgMgMAAgRIAAlsQAAgSAMgMQAMgNASAAIItAAQASAAAMANQAMAMAAASIAAFsQAAARgMAMQgMANgSAAIjPAAIANA2QAAANgJAJQgJAKgNAAgAhADtQAAAFADADQAEADAEAAIBrAAQAEAAAEgDQADgDAAgFIgOg3IhlAAgAkmjwQgGAGAAAKIAAFsQAAAJAGAGQAHAHAJAAIItAAQAJAAAHgHQAGgGAAgJIAAlsQAAgKgGgGQgHgHgJAAIotAAQgJAAgHAHg");
	this.shape.setTransform(65.95,56.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006D94").s().p("AkWAwQgNAAgKgJQgJgKAAgNIAAg/IJtAAIAAA/QAAANgJAKQgKAJgNAAg");
	this.shape_1.setTransform(65.95,80.75,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_2.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Uploadpropertiescentersvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AhFB9IAAjbIAUAAIAAgeIBjAAIAAAeIAUAAIAADbgAgxBpIBjAAIAAizIhjAAgAgdheIA7AAIAAgKIg7AAg");
	this.shape.setTransform(65,39.7,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_1.setTransform(69,54.7,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_2.setTransform(61,54.7,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_3.setTransform(69,46.7,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_4.setTransform(61,46.7,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_5.setTransform(69,30.7,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_6.setTransform(61,30.7,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_7.setTransform(69,38.7,2,2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_8.setTransform(61,38.7,2,2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_9.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Unlimitedtemplates03svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AgfBuIAAjbIA/AAIAADbg");
	this.shape.setTransform(28.45,70.55,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AhfAKIAAgTIC/AAIAAATg");
	this.shape_1.setTransform(62.85,90.4,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("Ah/AKIAAgTID/AAIAAATg");
	this.shape_2.setTransform(69.3,77.6,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("Ah/AKIAAgTID/AAIAAATg");
	this.shape_3.setTransform(69.3,50.7,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("Ah/AKIAAgTID/AAIAAATg");
	this.shape_4.setTransform(69.3,64.7,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AkLDbIAAm1IIXAAIAAG1gAj3DHIHvAAIAAlNInvAAgAj3iaIHvAAIAAgsInvAAg");
	this.shape_5.setTransform(58.55,63.45,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AkVDlIAAnJIIrAAIAAHJg");
	this.shape_6.setTransform(56.55,65.45,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_7.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Unlimitedtemplates02svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AgfBLIAAiVIA/AAIAACVg");
	this.shape.setTransform(76.45,71.55,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("AgfBLIAAiVIA/AAIAACVg");
	this.shape_1.setTransform(36.45,71.55,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00C4E3").s().p("Ai1AgIAAg/IFrAAIAAA/g");
	this.shape_2.setTransform(66.5,43.65,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_3.setTransform(55.9,84.4,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_4.setTransform(55.9,71.6,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_5.setTransform(55.9,58.7,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#101828").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_6.setTransform(95.9,84.4,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#101828").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_7.setTransform(95.9,71.6,2,2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#101828").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_8.setTransform(95.9,58.7,2,2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#101828").s().p("AkLDbIAAm1IIXAAIAAG1gAj3DHIHvAAIAAlNInvAAgAj3iaIHvAAIAAgsInvAAg");
	this.shape_9.setTransform(66.55,55.45,2,2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AkVDlIAAnJIIrAAIAAHJg");
	this.shape_10.setTransform(64.55,57.45,2,2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_11.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Unlimitedtemplates01svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AgfBLIAAiVIA/AAIAACVg");
	this.shape.setTransform(44.45,63.55,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("Ai2AgIAAg/IFtAAIAAA/g");
	this.shape_1.setTransform(74.5,35.65,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AhfAKIAAgTIC/AAIAAATg");
	this.shape_2.setTransform(78.85,76.4,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("Ah/AKIAAgTID/AAIAAATg");
	this.shape_3.setTransform(85.3,63.6,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("Ah/AKIAAgTID/AAIAAATg");
	this.shape_4.setTransform(85.3,50.7,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AkLDbIAAm1IIXAAIAAG1gAj3DHIHvAAIAAlNInvAAgAj3iaIHvAAIAAgsInvAAg");
	this.shape_5.setTransform(74.55,47.45,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AkVDlIAAnJIIrAAIAAHJg");
	this.shape_6.setTransform(72.55,49.45,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0)").s().p("AqTIwIAAxfIUnAAIAARfg");
	this.shape_7.setTransform(66,56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Submitinspectioncursorsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AgIAbIgqAWIAAh8IBlBGIgqAWIAaAyIgSAJgAgeAQIArgXIgrgeg");
	this.shape.setTransform(56.15,54.25,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgjgsIBHAyIhHAng");
	this.shape_1.setTransform(55.25,51.8,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AlnFoIAArPILPAAIAALPg");
	this.shape_2.setTransform(36,36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72,72);


(lib.Submitinspectionclicksvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AgVAIIAdgdIAOAOIgdAdg");
	this.shape.setTransform(11.45,61.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AgVAIIAdgdIAOAOIgdAdg");
	this.shape_1.setTransform(60.85,11.65,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgVgHIAOgOIAdAdIgOAOg");
	this.shape_2.setTransform(11.05,11.65,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AgUAKIAAgTIAqAAIAAATg");
	this.shape_3.setTransform(5.9,36,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgUAKIAAgTIAqAAIAAATg");
	this.shape_4.setTransform(66,36,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgJAVIAAgqIATAAIAAAqg");
	this.shape_5.setTransform(36,66.1,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#101828").s().p("AgJAVIAAgqIATAAIAAAqg");
	this.shape_6.setTransform(36,6,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0)").s().p("AlnFoIAArPILPAAIAALPg");
	this.shape_7.setTransform(36,36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72,72);


(lib.Submitinspectionbuttonsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag0A1IAAhpIBpAAIAAAUIhVAAIAABVg");
	this.shape.setTransform(33.85,33.95,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("Ag/BhQgOAAgJgKQgKgJAAgOIAAh/QAAgOAKgJQAJgKAOAAIB/AAQAOAAAJAKQAKAJAAAOIAAB/QAAAOgKAJQgJAKgOAAg");
	this.shape_1.setTransform(35.95,36.05,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AlnFoIAArPILPAAIAALPg");
	this.shape_2.setTransform(36,36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72,72);


(lib.Realtimeupdatessvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#006D94").s().p("AiiAWIAbgWIAZAbQAJg0AqgkQAqgkA2AAQAmAAAhASQAiARAUAfIgdAVQgQgZgagNQgZgOgdAAQgpABggAbQggAbgHAoIAegbIAYAbIhMBBg");
	this.shape.setTransform(24.75,15.7,1,1,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("AhrBQQgigRgVgfIAegUQAQAXAZAOQAaANAcAAQAqAAAggbQAggaAHgoIgfAaIgXgbIBMhBIBBBMIgBAAIgaAWIgZgcQgJA1gqAkQgqAkg3AAQglAAghgSg");
	this.shape_1.setTransform(17.275,26.35,1,1,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AjRDSIAAmjIGjAAIAAGjg");
	this.shape_2.setTransform(21,21,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,42,42);


(lib.Reportsrightsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AhwCgQgEAAgDgDQgDgDAAgEIAAkrQAAgEADgDQADgDAEAAICWAAIADABIAEACIBLBLIACADIABAEIAADgQAAAEgDADQgDADgEAAgAhmCMIDNAAIAAjMIhBAAQgEAAgDgDQgDgDAAgEIAAhBIiCAAgABZhUIgpgpIAAApIApAAg");
	this.shape.setTransform(26.95,35.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("AgaAbIAAg1IA1AAIAAA1g");
	this.shape_1.setTransform(22.5,21.25,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgJAqIAAhTIATAAIAABTg");
	this.shape_2.setTransform(15.1,24.35,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00C4E3").s().p("AgaAbIAAg1IA1AAIAAA1g");
	this.shape_3.setTransform(22.5,42.7,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgJAqIAAhTIATAAIAABTg");
	this.shape_4.setTransform(15.1,45.75,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhvCWIAAkrICUAAIBLBLIAADgg");
	this.shape_5.setTransform(27,34.95,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0)").s().p("AkNFeIAAq7IIbAAIAAK7g");
	this.shape_6.setTransform(27,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54,70);


(lib.Reportsleftsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AhwCgQgEAAgDgDQgDgDAAgEIAAkrQAAgEADgDQADgDAEAAICWAAIADABIAEACIBLBLIACADIABAEIAADgQAAAEgDADQgDADgEAAgAhmCMIDNAAIAAjMIhBAAQgEAAgDgDQgDgDAAgEIAAhBIiCAAgABZhUIgpgpIAAApIApAAg");
	this.shape.setTransform(26.95,35.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AhMA3QgDgCAAgFQAAgEADgDIA2g0QADgDAEAAQAEAAADADIANANIApgnIgTAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIArAAIAEABQADABACAEIABAEIAAArQAAAEgDACQgDADgEAAQgEAAgDgDQgDgCAAgEIAAgTIgwAuQgCADgFAAQgEAAgCgDIgOgOIgvAuQgDADgEAAQgEAAgDgDg");
	this.shape_1.setTransform(26.95,38.25,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhvCWIAAkrICUAAIBLBLIAADgg");
	this.shape_2.setTransform(27,34.95,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0)").s().p("AkNFeIAAq7IIbAAIAAK7g");
	this.shape_3.setTransform(27,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54,70);


(lib.Reportscentersvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AhwCgQgEAAgDgDQgDgDAAgEIAAkrQAAgEADgDQADgDAEAAICWAAIADABIAEACIBLBLIACADIABAEIAADgQAAAEgDADQgDADgEAAgAhmCMIDNAAIAAjMIhBAAQgEAAgDgDQgDgDAAgEIAAhBIiCAAgABZhUIgpgpIAAApIApAAg");
	this.shape.setTransform(26.95,35.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006D94").s().p("AgPArIAAhVIAfAAIAABVg");
	this.shape_1.setTransform(37.7,45.8,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#006D94").s().p("AgPBAIAAh/IAfAAIAAB/g");
	this.shape_2.setTransform(26.95,41.5,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006D94").s().p("AgPAVIAAgqIAfAAIAAAqg");
	this.shape_3.setTransform(16.2,50.1,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhvCWIAAkrICUAAIBLBLIAADgg");
	this.shape_4.setTransform(27,34.95,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0)").s().p("AkNFeIAAq7IIbAAIAAK7g");
	this.shape_5.setTransform(27,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54,70);


(lib.Inspectionsuploadedlogosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AghBbIhqi1IBHAAIBGB6IAfg1IgfAAIgphFICzAAIhpC1g");
	this.shape.setTransform(65.95,38.15,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AlJEYIAAovIKTAAIAAIvg");
	this.shape_1.setTransform(66,56,2,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Inspectionsuploadeddocsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AhhCDQgEAAgDgDQgDgDAAgEIAAjxQAAgEADgDQADgDAEAAICNAAQAGAAABADIA2A2QADADAAAEIAAC7QAAAEgDADQgCADgFAAgAhXBvICvAAIAAicIg2AAQgEAAgDgDQgDgEAAgDIAAg3IhvAAgABVhBIgpgqIAAAqIApAAg");
	this.shape.setTransform(64.4,38.8,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("Ag1AKIAAgTIBrAAIAAATg");
	this.shape_1.setTransform(64.45,48.8,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgaAKIAAgTIA1AAIAAATg");
	this.shape_2.setTransform(58.95,27.6,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("Ag1AKIAAgTIBrAAIAAATg");
	this.shape_3.setTransform(64.45,38.2,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0)").s().p("AlJEYIAAovIKTAAIAAIvg");
	this.shape_4.setTransform(66,56,2,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Inspectionsuploadeddesktopsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("Ag1EMQgNAAgJgKQgJgJAAgNIANg2IjPAAQgRAAgNgNQgMgMAAgRIAAlsQAAgSAMgMQAMgNASAAIItAAQASAAAMANQAMAMAAASIAAFsQAAARgMAMQgMANgSAAIjPAAIANA2QAAANgJAJQgJAKgNAAgAhADtQAAAFADADQAEADAEAAIBrAAQAEAAAEgDQADgDAAgFIgOg3IhlAAgAkmjwQgGAGAAAKIAAFsQAAAJAGAGQAHAHAJAAIItAAQAJAAAHgHQAGgGAAgJIAAlsQAAgKgGgGQgHgHgJAAIotAAQgJAAgHAHg");
	this.shape.setTransform(65.95,56.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006D94").s().p("AkWAwQgNAAgKgJQgJgKAAgNIAAg/IJtAAIAAA/QAAANgJAKQgKAJgNAAg");
	this.shape_1.setTransform(65.95,80.75,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AlJEYIAAovIKTAAIAAIvg");
	this.shape_2.setTransform(66,56,2,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132,112);


(lib.Cover = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhzBDIAAiFIDnAAIAACFg");
	this.shape.setTransform(0,6.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.6,0,23.299999999999997,13.4);


(lib.Conductinspectionsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAKQgEAAgDgDQgDgDAAgEQAAgDADgDQADgDAEAAIAVAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAg");
	this.shape.setTransform(96.75,79.7,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AhfDBQgSAAgMgNQgNgMAAgSIAAkrQAAgSANgMQAMgMASAAIDAAAQARAAANAMQAMAMAAASIAAErQAAASgMAMQgNANgRAAgAhvilQgHAHAAAJIAAErQAAAKAHAGQAGAHAKgBIDAAAQAJABAGgHQAHgGAAgKIAAkrQAAgJgHgHQgGgGgJgBIjAAAQgKABgGAGg");
	this.shape_1.setTransform(96.75,51.8,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#006D94").s().p("AhfC3QgOAAgJgKQgKgKAAgNIAAkrQAAgOAKgJQAJgKAOABIDAAAQANgBAKAKQAJAJAAAOIAAErQAAANgJAKQgKAKgNAAgAhfBrIDAAAIAAjqIjAAAg");
	this.shape_2.setTransform(96.75,51.8,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AisDDIAAhRQAAgeATgWQATgWAdgFIBFgKIAGgiQgSgRgKgWQgKgYAAgYQAAgsAYgbQAZgbApAAQArAAAYAaQAYAaAAAuQAAAXgKAXQgLAXgRARIAGAjIBEAKQANADALAFIAAAXQgMgJgPgCIhGgKIg2BMIg2hMIhGAKQgVAEgPAQQgOAQAAAXIAABRgAggiVQgQAVAAAgQAAAVAJAVQAKAVAQANIAEADIgIAxIAnA3IAng3IgIgyIAFgDQAPgOAKgVQAKgUAAgUQAAgegMgUQgSgcgpAAQgkAAgSAZg");
	this.shape_3.setTransform(36.45,41.5,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgJAgIAAhAIATAAIAABAg");
	this.shape_4.setTransform(61.4,74,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgJAgIAAhAIATAAIAABAg");
	this.shape_5.setTransform(19.6,74,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00C4E3").s().p("AinBQIAAhQQAAgaARgTQAQgUAagDIBMgMIAxBGIAyhGIBMAMQAOACALAHIAACLg");
	this.shape_6.setTransform(37.45,64.4,2,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00C4E3").s().p("AhjAKIAAgTIDHAAIAAATg");
	this.shape_7.setTransform(160,3.8,2,2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_8.setTransform(176,69.8,2,2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_9.setTransform(144,69.8,2,2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_10.setTransform(176,57.8,2,2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_11.setTransform(168,57.8,2,2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_12.setTransform(160,57.8,2,2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_13.setTransform(152,57.8,2,2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_14.setTransform(144,57.8,2,2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_15.setTransform(176,45.8,2,2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_16.setTransform(168,45.8,2,2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_17.setTransform(160,45.8,2,2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_18.setTransform(152,45.8,2,2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_19.setTransform(144,45.8,2,2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_20.setTransform(176,33.8,2,2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_21.setTransform(168,33.8,2,2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_22.setTransform(160,33.8,2,2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_23.setTransform(152,33.8,2,2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_24.setTransform(144,33.8,2,2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_25.setTransform(176,21.8,2,2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_26.setTransform(168,21.8,2,2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_27.setTransform(160,21.8,2,2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_28.setTransform(152,21.8,2,2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#101828").s().p("AgJAUIAAgnIATAAIAAAng");
	this.shape_29.setTransform(144,21.8,2,2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#101828").s().p("AAKC0IAAgoIgTAAIAAAoIh4AAIAAlnIEDAAIAAFngAAeB4IAAAoIBQAAIAAk/IjbAAIAAE/IBQAAIAAgog");
	this.shape_30.setTransform(160,45.8,2,2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AurHMIAAuXIdXAAIAAOXg");
	this.shape_31.setTransform(94,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,188,92);


(lib.Conductinspectionlogosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AgSAxIg4hhIAlAAIAmBBIAQgcIgQAAIgVglIBfAAIg4Bhg");
	this.shape.setTransform(96.8,49.8,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AurHMIAAuXIdXAAIAAOXg");
	this.shape_1.setTransform(94,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,188,92);


(lib.Conductinspectionformsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AggACIAOgNIALALIAagaIAOAOIgoAng");
	this.shape.setTransform(87.5,35.95,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AgjAKIAAgTIBGAAIAAATg");
	this.shape_1.setTransform(105.4,36.1,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AAAAOIgOAPIgOgOIAPgPIgPgOIAOgOIAOAPIAPgPIAOAOIgPAOIAPAPIgOAOg");
	this.shape_2.setTransform(88.05,49.75,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AgjAKIAAgTIBGAAIAAATg");
	this.shape_3.setTransform(105.4,50.1,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AggACIAOgNIALALIAagaIAOAOIgoAng");
	this.shape_4.setTransform(87.5,63.95,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgjAKIAAgTIBGAAIAAATg");
	this.shape_5.setTransform(105.4,64.1,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0)").s().p("AurHMIAAuXIdXAAIAAOXg");
	this.shape_6.setTransform(94,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,188,92);


(lib.Cogsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AgqCAIgRgHQgIgDgDgIQgDgHADgIIAFgMQgJgHgIgKIgKAEQgIADgHgDQgHgDgEgIIgHgRQgDgHADgIQADgHAIgDIAKgFQgCgMACgLIgMgFQgIgDgDgIQgDgHADgIIAHgRQADgHAIgEQAIgDAHADIAMAFQAHgJAKgIIgEgKQgDgIADgHQADgHAIgEIARgHQAHgDAIADQAHADADAIIAFAKQALgCAMACIAFgMQAEgJAHgCQAHgDAIADIARAHQAHADAEAIQADAIgDAHIgFAMQALAJAGAIIAKgEQAIgDAHADQAHADAEAIIAHARQADAHgDAIQgDAHgIADIgKAFQACALgCAMIAMAFQAIAEADAHQADAIgDAHIgHARQgDAHgIAEQgIADgHgDIgMgFQgHAJgKAIIAEAKQADAIgDAHQgEAIgHADIgRAHQgHADgIgDQgHgDgDgIIgFgKQgMACgLgCIgFAMQgDAIgIADIgHABgAgigiQgPAPAAATQAAAVAPAOQAPAPATAAQAVAAAOgPQAPgOAAgVQAAgTgPgPQgOgPgVAAQgTAAgPAPg");
	this.shape.setTransform(25.8388,25.8998,1.9981,2.0019);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(30));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,51.7,51.8);


(lib.Backgroundsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AEuBrIAAgKQAAgTgNgMQgNgNgRAAIjIAAQgiAAgTgeQgTAegiAAIjSAAQgSAAgNANQgNAMAAATIAAAKIgUAAIAAgKQAAgbASgTQAUgSAaAAIDSAAQASAAANgNQANgNAAgRIAAg5IglAkIgOgOIA8g9IA+A/IgPAOIglgmIAAA5QgBARANANQANANASAAIDIAAQAaAAATASQASATAAAbIAAAKg");
	this.shape.setTransform(42.8,158.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_1.setTransform(25.575,189.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_2.setTransform(21.275,189.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_3.setTransform(16.975,189.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_4.setTransform(25.575,184.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_5.setTransform(21.275,184.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_6.setTransform(16.975,184.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_7.setTransform(25.575,180.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_8.setTransform(21.275,180.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#101828").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_9.setTransform(16.975,180.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00C4E3").s().p("AAVCCIAAg2IgqAAIAAA2IhLAAIAAjqIDBgZIAAEDg");
	this.shape_10.setTransform(21.275,185.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#101828").s().p("AA2AQIAAgMIhsAAIAAAMIgTAAIAAgfICTAAIAAAfg");
	this.shape_11.setTransform(43.8,169.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_12.setTransform(48.125,189.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_13.setTransform(43.825,189.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_14.setTransform(39.525,189.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_15.setTransform(48.125,184.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_16.setTransform(43.825,184.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_17.setTransform(39.525,184.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_18.setTransform(48.125,176.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_19.setTransform(43.825,176.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_20.setTransform(39.525,176.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_21.setTransform(48.125,180.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_22.setTransform(43.825,180.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgKALIAAgVIAVAAIAAAVg");
	this.shape_23.setTransform(39.525,180.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#101828").s().p("Ag0AKIAAgTIBpAAIAAATg");
	this.shape_24.setTransform(65.35,189.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#101828").s().p("Ag0AKIAAgTIBpAAIAAATg");
	this.shape_25.setTransform(65.35,184.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#101828").s().p("Ag0AKIAAgTIBpAAIAAATg");
	this.shape_26.setTransform(65.35,180.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#101828").s().p("AhfAKIAAgTIC/AAIAAATg");
	this.shape_27.setTransform(65.35,175.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#006D94").s().p("AAWCMIAAg2IgqAAIAAA2IhMAAIAAkWIDBAAIAAEWg");
	this.shape_28.setTransform(43.8,184.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#00C4E3").s().p("AAWB2IAAg2IgrAAIAAA2IhAAAIAAjrICrAAIAADrg");
	this.shape_29.setTransform(65.35,187);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#101828").s().p("AgJCVIAAkpIATAAIAAEpg");
	this.shape_30.setTransform(322,198.15);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#00C4E3").s().p("AhzBfIAAi9IDoAAIgrBeIArBfg");
	this.shape_31.setTransform(336.9,192.775);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#101828").s().p("AiFC7QgUAAgOgOQgOgNAAgVIAAkWQAAgTAOgOQAOgOAUAAQAEAAADADQADADAAAEIAABBIEnAAQAEAAADADQADADAAAEIAAEWQAAAEgDADQgDADgEAAgAh7BmQAAAEgDADQgDADgEAAQgLAAgJAIQgIAIAAALQAAAMAIAIQAIAIAMAAIEnAAIAAkCIkdAAgAiciaQgFAHAAAIIAADwQAKgGAIgCIAAkBQgIADgFAHg");
	this.shape_32.setTransform(390.075,204.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#101828").s().p("ABBBgIAAgUIAWAAIAAhXIgWAAIAAgTIAWAAIAAgtIhXAAIAAAtIAVAAIAAATIgVAAIAAAVIgUAAIAAhVIhCAAIAACXIBCAAIAAgWIAUAAIAAAWIAVAAIAAAUIh/AAIAAi/IDVAAIAAC/g");
	this.shape_33.setTransform(392.225,208.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#00C4E3").s().p("Ag1AbIAAgWQAAgMAKgJQAJgKANAAIArAAQANAAAKAKQAJAJAAAMIAAAWg");
	this.shape_34.setTransform(417.975,188.85);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#101828").s().p("AgyBKQgDgEACgFIgBgCIAAjLQAAgEADgDQADgDAEAAIBVAAQAEAAADADQADADAAAEIAADLIAAACQABAGgDADIgzBNgAAABzIAcgqIg3AAgAAKA1IAXAAIAAi3IgXAAgAggA1IAXAAIAAi3IgXAAg");
	this.shape_35.setTransform(417.9969,208.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#006D94").s().p("AgqBmIAAjLIBVAAIAADLg");
	this.shape_36.setTransform(418,204.95);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#101828").s().p("AgEBAIAAgKQAAgSgMgNQgNgNgSAAIkiAAQgbAAgSgRQgTgTAAgbIAAgKIAUAAIAAAKQAAASANANQANANASAAIEiAAQAiAAASAdQATgdAjAAIEXAAQASAAANgNQANgNAAgSIAAgKIAUAAIAAAKQAAAbgTATQgSARgbAAIkXAAQgSAAgNANQgNANAAASIAAAKg");
	this.shape_37.setTransform(547.975,143.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#101828").s().p("ABiBzIAAgvQAAgLgIgIQgHgJgLgCIgmgGIgiAvIghgvIgmAGQgLACgHAJQgHAIgBALIAAAvIgTAAIAAgvQgBgTAMgOQANgNASgEIAmgFIACgOQgWgWAAgeQAAgbAQgSQAQgQAYAAQAaAAAQAQQAPARAAAcQAAAcgVAXIACAPIAlAFQASAEANANQAMAOAAATIAAAvgAgahUQgKALAAAUQAAAZATAQIAEADIgEAdIARAZIASgZIgEgdIAEgEQAJgHAFgLQAFgLAAgLQAAgpglAAQgRgBgJALg");
	this.shape_38.setTransform(548.5,164.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#101828").s().p("AgJATIAAglIATAAIAAAlg");
	this.shape_39.setTransform(554.65,174.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#101828").s().p("AgJATIAAglIATAAIAAAlg");
	this.shape_40.setTransform(542.35,174.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#006D94").s().p("AhrAvIAAgvQAAgOAKgMQAKgLAPgCIAsgHIAcApIAdgpIAsAHQAPACAKALQAKAMAAAOIAAAvg");
	this.shape_41.setTransform(548.5,171.475);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#101828").s().p("AgMAXQgGgBgDgCIAFgKIAHADIAJABQAIAAAAgEQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAgBgBAAIgQgDQgFgCgCgCQgCgCgBgGQABgFACgDQACgDAFgDQAHgCAFAAIAKACQAEAAAFACIgGAKQgFgDgIAAQgEAAgCABQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAABABIARADQADABADADQADACAAAGQAAAEgDADQgDAEgEACQgFACgHAAQgGAAgGgCg");
	this.shape_42.setTransform(562.5,90);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#101828").s().p("AgGAaQgEgFAAgJIAAgSIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABABABAAQAAAAABAAQAEAAACgCIADAKIgEACIgHABQgIAAgFgEg");
	this.shape_43.setTransform(558.15,89.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#101828").s().p("AgOAZIAAgwIAOAAIAAAHQABgEAEgCQAGgCAEAAIAAANIgDAAQgHAAgDAEQgCADAAAGIAAAXg");
	this.shape_44.setTransform(554.35,89.975);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#101828").s().p("AgMAWQgHgDgDgGQgEgFAAgIQAAgHAEgFQADgFAHgEQAGgDAGAAQAHAAAHADQAGAEADAFQAEAFgBAHQABAIgEAFQgCAFgHAEQgGADgIAAQgHAAgFgDgAgIgJQgEAFABAEQgBAFAEAFQADADAFAAQAGAAADgDQAEgEAAgGQAAgFgEgEQgEgEgFABQgEgBgEAEg");
	this.shape_45.setTransform(549.25,90);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#101828").s().p("AgZAiIAAhCIANAAIAAAGQAGgGAIgBQAGABAHADQAFADADAGQADAFAAAIQAAAHgDAEQgDAHgFACQgGAEgHAAQgIAAgFgHIAAAYgAgIgRQgDAEAAAGQAAAGADACQADAEAFAAQAFAAAEgEQADgCAAgGQAAgGgDgEQgEgEgFAAQgFAAgDAEg");
	this.shape_46.setTransform(543.375,90.85);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#101828").s().p("AgLAWQgGgDgEgGQgDgFgBgIQABgHADgFQACgFAHgEQAHgDAFAAQAIAAAFADQAGADADAGQAEAGAAAHIAAADIgkAAQABAFADACQAEADAEAAQAEAAAEgBQACgCADgCIAHAIQgHAIgNAAQgHAAgGgDgAgHgLQgDAEAAAEIAWAAQAAgEgDgEQgEgCgFAAQgEAAgDACg");
	this.shape_47.setTransform(537.25,90);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#101828").s().p("AAMAfIgMgRIgMAAIAAARIgPAAIAAg+IAbAAQAHABAHACQAGADAEAFQACAFAAAHQABAIgEADQgEAGgFACIAOAUgAgMACIALAAQAGAAADgCQAEgDAAgFQAAgEgEgEQgDgDgGAAIgLAAg");
	this.shape_48.setTransform(531.35,89.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#101828").s().p("AgFAaQgFgFAAgJIAAgSIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABABABAAQAAAAABAAQADAAACgCIAFAKIgGACIgGABQgHAAgFgEg");
	this.shape_49.setTransform(576,78.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#101828").s().p("AALAZIAAgZQAAgFgDgEQgCgCgFAAQgEAAgEADQgDAEAAAFIAAAYIgOAAIAAgwIAOAAIAAAGIAHgFQAEgCAEAAQAJAAAFAGQAGAFAAALIAAAbg");
	this.shape_50.setTransform(570.975,79.175);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#101828").s().p("AgLAWQgGgCgEgHQgEgHAAgGQAAgHAEgFQAEgFAGgEQAFgDAGAAQAIAAAGADQAEADAFAGQACAGAAAHIAAADIgjAAQABAFAEACQADADAFAAQADAAADgBQADgBADgDIAHAIQgHAIgMAAQgIAAgGgDgAgHgLQgDAEgBAEIAYAAQgBgEgEgEQgCgCgGAAQgEAAgDACg");
	this.shape_51.setTransform(565,79.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#101828").s().p("AAbAZIAAgZQAAgFgDgEQgCgCgEAAQgFAAgDADQgDADAAAFIAAAZIgNAAIAAgZQAAgLgJAAQgFAAgDADQgDADAAAFIAAAZIgOAAIAAgwIANAAIAAAGIAHgFQAEgCAFAAQAEAAAFACIAGAGQADgEAEgBQAFgDAFAAQAJAAAFAGQAGAFAAALIAAAbg");
	this.shape_52.setTransform(557.425,79.175);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#101828").s().p("AgLAWQgHgDgDgGQgDgFgBgIQABgHADgFQADgFAGgEQAHgDAFAAQAHAAAGADQAGADADAGQADAFABAIIgBADIgjAAQAAAFAEACQAEADAEAAQAEAAADgBQADgCADgCIAHAIQgHAIgNAAQgIAAgFgDgAgHgLQgCADgBAFIAWAAQgBgFgDgDQgDgCgFAAQgEAAgDACg");
	this.shape_53.setTransform(549.85,79.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#101828").s().p("AgNAgQgHgCgDgDIAFgKQAEADAEABIAJACQAGAAAEgEQAEgDAAgHIAAgCQgGAGgJAAQgGAAgGgDQgFgCgEgGQgDgEAAgHQAAgHADgFQAFgGAEgDQAGgDAGAAQAKAAAFAHIAAgGIAOAAIAAAoQAAAMgHAHQgHAHgNAAQgHAAgGgCgAgIgSQgEAEAAAFQAAAFAEADQADADAFAAQAGAAADgDQAEgDAAgFQAAgGgEgDQgEgDgFAAQgEAAgEADg");
	this.shape_54.setTransform(543.675,80.075);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#101828").s().p("AgOAXQgDgCgCgDQgDgEAAgDQAAgHAGgEQADgDAMAAIAKAAQAAgFgCgCQgDgCgFgBIgHABIgHAEIgFgKIAKgEIAKgCQALAAAGAFQAGAGAAAKIAAAbIgNAAIAAgFQgEAGgKAAQgFAAgFgCgAgIAKQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQADACADgBQADABACgCQADgCABgDIAAgFIgJAAQgIAAAAAGg");
	this.shape_55.setTransform(537.7,79.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#101828").s().p("AALAZIAAgZQAAgGgDgDQgCgCgFAAQgEAAgDADQgDAEAAAFIAAAYIgPAAIAAgwIAOAAIAAAGQADgDAEgCIAIgCQAJAAAFAGQAGAFAAALIAAAbg");
	this.shape_56.setTransform(531.975,79.175);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#101828").s().p("AgNAXQgEgBgDgEIgCgHQAAgIAFgDQAEgDAMAAIAKAAQAAgFgDgCQgCgCgFgBIgIABIgGAEIgFgKIAJgEIALgCQAKAAAHAFQAGAGAAAKIAAAbIgNAAIAAgFQgDAGgLAAQgGAAgDgCgAgJAKQAAABABAAQAAABAAAAQAAABABAAQAAABABAAQACACADgBQADABADgCQACgBACgEIAAgFIgJAAQgIAAgBAGg");
	this.shape_57.setTransform(525.95,79.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#101828").s().p("AAWAfIAAglIgSAeIgGAAIgSgdIAAAkIgPAAIAAg+IANAAIAWAnIAYgnIALAAIAAA+g");
	this.shape_58.setTransform(519,78.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#101828").s().p("AgNAeQgHgDgCgFQgDgGAAgHQAAgIADgFQADgFAGgDQAFgDAHAAQAIAAAFAGIAAgYIAOAAIAABCIgNAAIAAgGQgFAHgJAAQgGAAgGgEgAgIAAQgDADAAAGQAAAFADAEQAEAEAEAAQAGAAADgEQAEgEAAgFQAAgHgEgCQgDgEgGAAQgEAAgEAEg");
	this.shape_59.setTransform(484.075,172.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#101828").s().p("AgLAVQgHgDgDgGQgDgEgBgIQABgHADgFQADgGAGgDQAGgDAHAAQAHAAAFADQAGADADAGQADAFABAHIgBAEIgjAAQABAEADADQAEACAEAAIAHgBIAGgDIAHAIQgHAIgNAAQgGAAgHgEgAgHgLQgCACgBAFIAWAAQAAgEgDgCQgEgEgEAAQgEAAgEADg");
	this.shape_60.setTransform(478.3,173.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#101828").s().p("AgOAeQgGgDgCgFQgDgGAAgHQAAgIADgFQADgFAFgDQAGgDAHAAQAIAAAFAGIAAgYIAOAAIAABCIgNAAIAAgGQgGAHgIAAQgGAAgHgEgAgIAAQgDADAAAGQAAAFADAEQAEAEAEAAQAGAAADgEQAEgEAAgFQAAgGgEgDQgDgEgGAAQgEAAgEAEg");
	this.shape_61.setTransform(472.175,172.325);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#101828").s().p("AgOAXQgFgDgBgCQgCgEAAgEQAAgHAFgDQAGgDAKgBIAKAAQAAgEgDgCQgCgDgFAAIgIACQgEABgCACIgFgKQAEgDAGgCIAKgBQALAAAGAGQAGAFAAALIAAAaIgNAAIAAgGQgEAHgKAAQgEAAgGgCgAgJAJQAAABABABQAAAAAAABQAAAAABABQAAAAABAAQACADAEAAQACAAADgDQACgBACgDIAAgFIgJAAQgJAAAAAFg");
	this.shape_62.setTransform(466.25,173.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#101828").s().p("AgNAVQgGgDgDgGQgDgEAAgIQAAgHADgFQADgFAGgEQAHgDAGAAQAIAAAGADQAFADAFAGQADAFAAAHQAAAIgDAEQgFAHgFACQgHAEgHAAQgFAAgIgEgAgIgJQgDAFAAAEQAAAFADAEQAEAEAEAAQAGAAADgEQAEgDgBgGQABgFgEgEQgDgEgGAAQgEAAgEAEg");
	this.shape_63.setTransform(460.75,173.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_64.setTransform(456.45,172.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#101828").s().p("AgZAhIAAhBIANAAIAAAGQAGgGAIAAQAHAAAGADQAFADADAFQADAGAAAIQAAAHgDAFQgDAFgFADQgHAEgGAAQgIAAgFgGIAAAWgAgIgRQgDAEAAAGQAAAGADACQADAEAFAAQAFAAAEgEQADgCAAgGQAAgHgDgDQgEgEgFAAQgFAAgDAEg");
	this.shape_65.setTransform(452.175,174.025);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#101828").s().p("AgUAZQgIgIABgNIAAgjIAOAAIAAAiQAAAQANAAQAHAAADgDQAEgEAAgJIAAgiIAOAAIAAAjQAAANgHAIQgIAHgNAAQgMAAgIgHg");
	this.shape_66.setTransform(445.35,172.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#101828").s().p("AgMAYIABAAQgGgCgEgDIAFgKQADADAFABIAIABQAJAAAAgFQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAIgGgCIgKgCQgDAAgEgDQgDgDAAgFQAAgEADgFQADgDAFgCQAEgCAGAAIALABIAIADIgEAKQgGgEgJAAQgCAAgDACQgBAAAAABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAABABQAAAAAAABQAAAAABAAQAAABABAAIAHACIAJACQAEAAADADQADADAAAFQAAAFgDAEQgDADgFACQgGACgFAAIgMgBg");
	this.shape_67.setTransform(489.55,162.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#101828").s().p("AALAYIAAgYQAAgFgDgEQgCgDgFAAQgEABgDADQgEADAAAFIAAAYIgOAAIAAgvIAOAAIAAAGQAEgEADgBQADgBAFAAQAJgBAFAGQAGAFAAALIAAAag");
	this.shape_68.setTransform(484.075,162.35);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#101828").s().p("AgNAVQgGgDgDgGQgEgEABgIQgBgHAEgFQADgFAGgEQAHgDAGAAQAIAAAGADQAFADAEAGQADAFABAHQgBAIgDAEQgEAHgFACQgHAEgHAAQgFAAgIgEgAgIgJQgDAFgBAEQABAFADAEQAEAEAEAAQAGAAADgEQADgDABgGQgBgFgDgEQgDgEgGAAQgEAAgEAEg");
	this.shape_69.setTransform(478,162.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgCAAgEQAAgDADgCQACgCADgBQADABADACQADACAAADQAAADgDADQgDACgDABQgDgBgCgCg");
	this.shape_70.setTransform(473.725,161.25);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#101828").s().p("AgFAZQgFgEAAgIIAAgTIgHAAIAAgMIAHAAIAAgLIANAAIAAALIAMAAIAAAMIgMAAIAAASQAAADABACQABAAAAABQABAAAAAAQABAAABAAQAAAAABAAIAGgBIAEAJIgGADIgGABQgHAAgFgFg");
	this.shape_71.setTransform(470.35,161.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#101828").s().p("AgKAVQgHgDgDgGQgDgEAAgIQAAgHADgFQADgFAHgEQAGgDAHAAQAIAAAFADQAGADACAGIgLAGQgDgHgHAAQgFAAgEAEQgDAFAAAEQAAAGADADQAEAEAFAAQAGAAAEgGIALAFQgCAHgGACQgGAEgHAAQgGAAgHgEg");
	this.shape_72.setTransform(465.775,162.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#101828").s().p("AgMAVQgFgCgEgHQgDgEgBgIQABgHADgFQACgEAHgFQAGgDAHAAQAGAAAGADQAGADADAGQAEAFAAAHIAAAEIgkAAQABAEADADQAEACAEAAIAIgBIAEgDIAIAIQgHAIgNAAQgGAAgIgEgAgHgLQgDADAAAEIAWAAQAAgEgDgCQgDgEgFAAQgEAAgEADg");
	this.shape_73.setTransform(460.2,162.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#101828").s().p("AgaAhIAAhBIAOAAIAAAGQAFgGAJAAQAHAAAGADQAFADADAFQADAGABAIQgBAHgDAFQgDAFgFADQgHAEgGAAQgIAAgFgGIAAAWgAgIgRQgDADAAAHQAAAGADACQADAEAFAAQAGAAADgEQADgCAAgGQAAgHgDgDQgDgEgGAAQgFAAgDAEg");
	this.shape_74.setTransform(454.45,163.225);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#101828").s().p("AgMAYQgEgCgFgDIAFgKQACADAGABIAIABQAIAAABgFQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAIgHgCIgJgCQgEAAgDgDQgDgDAAgFQAAgFADgEQACgDAFgCQAFgCAHAAIAKABIAJADIgGAKQgFgEgIAAQgEAAgCACQgBAAAAABQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABABAAIAHACIAKACQADABADACQADADAAAFQAAAFgDAEQgDADgEACQgIACgEAAQgGAAgGgBg");
	this.shape_75.setTransform(448.75,162.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#101828").s().p("AALAYIAAgYQAAgFgDgEQgCgDgFAAQgEABgDADQgEADAAAFIAAAYIgOAAIAAgvIAOAAIAAAGQAEgEADgBQADgBAFAAQAJgBAFAGQAGAFAAALIAAAag");
	this.shape_76.setTransform(443.275,162.35);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#101828").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_77.setTransform(438.675,161.65);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#101828").s().p("AgYAZIAAgwIAOAAIAAAGQADgDAEgCQADgCAFAAQAJAAAFAGQAGAFAAALIAAAaIgOAAIAAgYQAAgGgDgDQgCgCgFAAQgEAAgDADQgEADAAAGIAAAYg");
	this.shape_78.setTransform(414.425,143.725);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#101828").s().p("AgNAWQgFgEgEgFQgEgGAAgHQAAgGAEgGQAEgGAFgDQAGgDAHAAQAIAAAGADQAFADAEAGQAEAHAAAFQAAAGgEAHQgEAFgFAEQgGADgIAAQgHAAgGgDgAgIgIQgDADAAAFQAAAHADADQAEAEAEgBQAFABAEgEQADgDAAgHQAAgFgDgDQgDgFgGAAQgFAAgDAFg");
	this.shape_79.setTransform(408.375,143.75);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgCAAgEQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_80.setTransform(404.075,142.625);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#101828").s().p("AgFAaQgFgFAAgIIAAgUIgHAAIAAgKIAHAAIAAgMIANAAIAAAMIAMAAIAAAKIgMAAIAAAUQAAAAAAABQAAABABAAQAAABAAAAQABABAAAAQABABAAAAQABAAAAABQAAAAABAAQAAAAABAAQADAAADgCIAEAKIgGACIgFABQgJAAgEgEg");
	this.shape_81.setTransform(400.7,143.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#101828").s().p("AgKAWQgHgEgDgFQgDgGAAgHQAAgGADgGQADgFAHgEQAFgDAIAAQAIAAAFADQAGAEACAFIgKAGQgFgHgGAAQgFABgDADQgEAEAAAFQAAAGAEAEQADAEAFgBQAHAAAEgGIAKAFQgCAGgGADQgFAEgIAAQgHAAgGgDg");
	this.shape_82.setTransform(396.125,143.75);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#101828").s().p("AgLAWQgGgEgEgFQgDgHgBgGQABgFADgHQAEgGAGgDQAFgDAHAAQAHAAAFADQAGADADAGQAEAGAAAGIAAAEIgkAAQABAFADACQADADAFgBIAHgBIAGgDIAHAIQgHAIgNAAQgHAAgGgDgAgHgLQgDADAAAFIAWAAQAAgEgDgEQgEgDgEAAQgEAAgEADg");
	this.shape_83.setTransform(390.55,143.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#101828").s().p("AgaAhIAAhAIAOAAIAAAFQAFgGAJAAQAHAAAGADQAFADAEAGQACAFAAAIQAAAHgCAFQgFAGgEADQgGADgHAAQgIAAgFgGIAAAWgAgIgRQgEADABAHQgBAGAEADQAEADAEAAQAFAAADgDQAEgDAAgGQAAgHgEgDQgCgEgGAAQgEAAgEAEg");
	this.shape_84.setTransform(384.8,144.575);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#101828").s().p("AgMAXQgFgBgEgCIAFgKQACACAGABIAIABQAIABABgFQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAgBAAIgQgEQgEgBgDgCQgDgDAAgFQAAgFADgDQACgDAGgDQAGgCAFAAIAKABIAIADIgFALQgGgFgHAAQgDABgDABQAAAAgBABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAQABAAAAAAIAQAEQAFACACACQADACAAAGQAAADgCAFQgDADgGACQgEACgHAAQgGAAgGgCg");
	this.shape_85.setTransform(379.1,143.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#101828").s().p("AgYAZIAAgwIAOAAIAAAGQADgDAEgCQADgCAFAAQAJAAAFAGQAGAFAAALIAAAaIgOAAIAAgYQAAgGgDgDQgCgCgFAAQgEAAgDADQgEADAAAGIAAAYg");
	this.shape_86.setTransform(373.625,143.725);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#101828").s().p("AgHAgIAAg+IAPAAIAAA+g");
	this.shape_87.setTransform(369.05,143);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#101828").s().p("AgFAaQgFgFAAgIIAAgUIgHAAIAAgKIAHAAIAAgMIANAAIAAAMIAMAAIAAAKIgMAAIAAAUQAAAAAAABQAAABAAAAQABABAAAAQAAABAAAAQABABABAAQAAAAABABQAAAAABAAQAAAAABAAIAGgCIAEAKIgGACIgGABQgHAAgFgEg");
	this.shape_88.setTransform(407.65,132.45);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgCAAgEQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_89.setTransform(404.375,131.825);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#101828").s().p("AAbAZIAAgZQAAgGgCgDQgDgCgEAAQgFAAgDADQgDADAAAFIAAAZIgNAAIAAgZQAAgLgJAAQgFAAgDADQgDADAAAFIAAAZIgOAAIAAgvIAOAAIAAAFIAGgFQAEgCAFAAIAJADQAEACACADQADgDAEgCQAGgCAEgBQAJAAAGAGQAFAFAAALIAAAbg");
	this.shape_90.setTransform(398.325,132.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#101828").s().p("AgMAbIAAAGIgNAAIAAhCIAOAAIAAAYQAFgGAIAAQAHAAAFADQAHAEACAFQADAEAAAIQAAAIgDAFQgDAGgGADQgFADgHAAQgJAAgFgHgAgIAAQgEADAAAGQAAAFAEAFQAEADAEAAQAEAAAFgDQADgFAAgFQAAgGgDgDQgEgEgFAAQgEAAgEAEg");
	this.shape_91.setTransform(390.675,132.075);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#101828").s().p("AgSATQgFgGgBgKIAAgaIAPAAIAAAXQgBANAKAAQAEAAAEgEQACgDAAgGIAAgXIAPAAIAAAvIgOAAIAAgGIgHAFQgDABgDAAQgJAAgHgFg");
	this.shape_92.setTransform(384.25,133);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#101828").s().p("AgOAfQgGgCgFgEIAFgLIAJAFIALACQAGAAADgCQADgCAAgDQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBIgFgCIgSgFQgFgDgDgCQgDgDAAgHQAAgFADgFQADgEAGgDQAGgDAIAAQAGAAAFACIALAEIgFALQgIgFgJAAQgGAAgCACQgDACAAADQAAAEADABIAVAHQAEABAEADQADADAAAHQAAAFgDAFQgDAFgGACQgGADgIAAIgOgCg");
	this.shape_93.setTransform(378.325,132.225);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#101828").s().p("AgLAYQgFgCgFgDIAFgKQACACAFACIAJACQAIAAAAgFQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAIgQgEQgEgBgDgCQgCgEgBgEQABgFACgEQACgDAGgCQAEgCAHAAIAKABIAJAEIgGAJQgGgEgHAAQgDAAgDACQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABQAAAAABAAIARAEQAEACACABQADADAAAFQAAAEgCAEQgDADgFADQgIACgEAAQgGAAgFgBg");
	this.shape_94.setTransform(434.6,232.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#101828").s().p("AALAYIAAgYQAAgGgDgDQgCgDgFAAQgEABgDADQgDADAAAGIAAAXIgPAAIAAguIAOAAIAAAFIAHgFIAIgBQAJgBAFAGQAGAFAAALIAAAag");
	this.shape_95.setTransform(429.125,232.65);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#101828").s().p("AgOAXQgEgCgCgDQgCgEAAgEQAAgHAFgDQAFgDALAAIAKAAQAAgFgDgCQgDgDgEAAIgIACIgGADIgFgKQAEgDAFgCIALgBQAKAAAHAGQAGAFAAALIAAAaIgNAAIAAgGQgEAHgKAAQgGAAgEgCgAgIAJQAAADACACQABABAEABQADgBADgBIAEgFIAAgFIgJAAQgIAAAAAFg");
	this.shape_96.setTransform(423.1,232.7);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_97.setTransform(419.1,231.775);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#101828").s().p("AgaAfIAAg+IAaAAQAJAAAFAEQAIADACAEQADAGABAHQgBAGgDAEQgCAFgIADQgFADgJAAIgMAAIAAARgAgMACIAMAAQAGAAADgCQADgDAAgEQAAgGgDgCQgDgDgGAAIgMAAg");
	this.shape_98.setTransform(414.65,231.95);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#101828").s().p("AgMAVQgGgDgDgFQgDgFAAgIQAAgGADgGQADgFAGgEQAGgDAGAAQAHAAAGADQAGADADAGQAEAFgBAHIAAAEIgkAAQACAFADACQADADAGAAIAGgCQADAAACgDIAIAIQgGAIgOAAQgIAAgGgEgAgGgKQgEABgBAGIAXAAQgBgGgDgBQgDgDgFgBQgDABgDADg");
	this.shape_99.setTransform(405.8,232.7);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#101828").s().p("AgFAZQgFgEAAgIIAAgTIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAATQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABAAABAAQAAABABAAIAGgCIADAKIgEACIgHABQgIAAgEgFg");
	this.shape_100.setTransform(401.1,232.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgDAAgDQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_101.setTransform(397.825,231.575);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#101828").s().p("AgOAeQgHgBgEgDIAFgMQAEAEAFABQAFACAGAAQAGAAADgCQADgBAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAIgFgDIgSgFQgFgDgDgCQgDgDAAgHQAAgFADgFQADgEAGgDQAGgCAHgBIAMACIAKAEIgEALQgJgFgJAAQgFABgDACQgDABAAADQAAADAEADIAJACIAMAEQAEABAEADQADAEAAAGQAAAFgDAFQgDAFgGACQgFACgJAAQgIAAgGgCg");
	this.shape_102.setTransform(393.625,231.95);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#101828").s().p("AgaAhIAAhBIAOAAIAAAGQAFgGAJAAQAHAAAGADQAEACAFAHQACAFAAAIQAAAHgCAFQgEAFgFAEQgGADgHAAQgHAAgGgGIAAAWgAgIgRQgEAEABAGQgBAGAEACQAEAEAEAAQAFAAAEgEQADgCAAgGQAAgGgDgEQgEgEgFAAQgFAAgDAEg");
	this.shape_103.setTransform(385.25,233.525);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#101828").s().p("AgSATQgFgGgBgKIAAgbIAPAAIAAAZQgBALAKAAQAFAAADgDQACgDAAgGIAAgYIAPAAIAAAwIgOAAIAAgGQgCAEgFABQgDACgDAAQgJAAgHgGg");
	this.shape_104.setTransform(378.85,232.725);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#101828").s().p("AgMAGIAAgLIAZAAIAAALg");
	this.shape_105.setTransform(374.075,232.575);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#101828").s().p("AAKAhIgOgTIgIAHIAAAMIgNAAIAAhBIANAAIAAAkIAUgSIARAAIgUAUIAVAbg");
	this.shape_106.setTransform(369.9,231.775);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#101828").s().p("AgOAYIAAgvIANAAIAAAHQADgFADgBQAEgBAGAAIAAAMIgDAAQgGAAgEAEQgCAEAAAFIAAAWg");
	this.shape_107.setTransform(364.925,232.65);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#101828").s().p("AgOAXQgEgCgCgDQgCgEAAgEQAAgHAFgDQAGgDAKAAIAKAAQAAgFgDgCQgCgDgFAAIgIACIgGADIgFgKQAEgDAGgCIAKgBQALAAAGAGQAGAFAAALIAAAaIgNAAIAAgGQgEAHgKAAQgGAAgEgCgAgIAJQgBADADACQABABAFABQACgBADgBIAEgFIAAgFIgJAAQgJAAABAFg");
	this.shape_108.setTransform(359.85,232.7);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#101828").s().p("AAWAfIAAgkIgSAeIgGAAIgTgeIAAAkIgNAAIAAg+IAMAAIAXAnIAWgnIANAAIAAA+g");
	this.shape_109.setTransform(352.9,231.95);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#101828").s().p("AgMAXIAAAAQgGgBgDgCIAFgKIAHADIAJABQAIABAAgFQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAgBgBAAIgQgEQgFgBgCgCQgCgCgBgGQABgFACgDQACgEAFgCQAHgCAFAAIAKABQAFABAEACIgGAKQgFgDgIAAQgFAAgBABQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAABABIARADQADABADADQADACAAAGQAAAEgDAEQgCAEgFABQgFACgHAAIgMgCg");
	this.shape_110.setTransform(342.8,174.25);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#101828").s().p("AAbAZIAAgZQAAgGgDgDQgCgCgEAAQgFAAgDADQgDADAAAFIAAAZIgNAAIAAgZQAAgLgJAAQgFAAgDADQgDADAAAFIAAAZIgOAAIAAgwIAOAAIAAAGQACgDAEgCQAEgCAFAAIAJACQADACADAEQADgEAEgBQAFgDAFAAQAJAAAGAGQAFAFAAALIAAAbg");
	this.shape_111.setTransform(335.725,174.225);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#101828").s().p("AgMAWQgGgEgDgFQgEgFABgIQgBgGAEgGQADgGAGgDQAHgDAGAAQAHAAAFADQAGADADAGQADAFAAAIIAAADIgkAAQACAEAEADQACADAGAAQADAAADgBQADgCACgCIAIAIQgHAIgNAAQgGAAgIgDgAgGgLQgDADgCAFIAXAAQAAgEgDgEQgEgCgEAAQgFAAgCACg");
	this.shape_112.setTransform(328.15,174.25);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#101828").s().p("AgFAaQgFgFAAgJIAAgSIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAABABQAAAAABABQAAAAABAAQAAAAABAAQAEAAACgCIADAKIgEACIgHABQgHAAgFgEg");
	this.shape_113.setTransform(323.45,173.75);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#101828").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_114.setTransform(320.075,173.55);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#101828").s().p("AgaAiIAAhCIAOAAIAAAGQAGgHAJAAQAHAAAFAEQAEACAFAHQACAGAAAGQAAAIgCAFQgEAGgFADQgFADgHAAQgJAAgFgHIAAAYgAgIgRQgDAEAAAFQAAAHADACQADAEAFAAQAGAAADgEQADgCAAgHQAAgFgDgEQgEgEgFAAQgEAAgEAEg");
	this.shape_115.setTransform(363.85,164.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#101828").s().p("AgSATQgGgGAAgKIAAgbIAOAAIAAAYQAAANAKAAQAEAAADgEQADgDAAgGIAAgYIAPAAIAAAwIgOAAIAAgGQgEAEgCABQgEABgDABQgKgBgGgFg");
	this.shape_116.setTransform(357.45,163.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#101828").s().p("AgMAFIAAgJIAZAAIAAAJg");
	this.shape_117.setTransform(352.675,163.35);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#101828").s().p("AALAYIgLgdIgKAdIgNAAIgSgvIANAAIALAfIANgfIAKAAIAMAfIAMgfIAMAAIgSAvg");
	this.shape_118.setTransform(346.85,163.475);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#101828").s().p("AgNAWQgGgEgDgFQgEgFAAgIQAAgGAEgGQAEgGAFgDQAHgDAGAAQAHAAAHADQAFADAEAGQAEAHAAAFQAAAGgEAHQgDAFgGAEQgGADgIAAQgHAAgGgDgAgIgIQgDADAAAFQAAAHADADQADADAFAAQAFAAAEgDQADgDAAgHQAAgFgDgDQgDgFgGAAQgFAAgDAFg");
	this.shape_119.setTransform(339.825,163.45);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_120.setTransform(335.5,162.55);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_121.setTransform(332.8,162.55);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#101828").s().p("AgNAWQgHgFgCgEQgDgFAAgIQAAgGADgGQADgFAGgEQAIgDAFAAQAGAAAIADQAGADADAGQADAGAAAGQAAAIgDAFQgDAFgGAEQgGADgIAAQgHAAgGgDgAgIgIQgDAEgBAEQABAGADAEQAEADAEAAQAFAAAEgDQADgEABgGQgBgEgDgEQgEgFgFAAQgEAAgEAFg");
	this.shape_122.setTransform(328.5,163.45);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#101828").s().p("AgXAfIAAg+IAvAAIAAAMIggAAIAAAQIAcAAIAAAMIgcAAIAAAWg");
	this.shape_123.setTransform(323.075,162.75);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#101828").s().p("AgNAgQgHgCgDgDIAGgKIAHAEIAKACQAFAAAEgEQADgDAAgHIAAgCQgFAGgIAAQgHAAgGgDQgGgDgDgFQgDgFAAgGQAAgGADgGQAEgGAFgDQAGgDAHAAQAJAAAFAHIAAgGIAOAAIAAAnQAAANgHAHQgHAHgNAAQgHAAgGgCgAgIgSQgDADAAAGQAAAFADADQAEADAEAAQAGAAADgDQAEgDAAgFQAAgFgEgEQgEgDgFAAQgDAAgFADg");
	this.shape_124.setTransform(314.05,164.325);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#101828").s().p("AgOAXQgEgCgCgDIgCgHQAAgHAFgEQAFgDALAAIAKAAQAAgFgCgCQgDgCgFgBIgHABIgHAEIgFgKQAEgDAGgCQAFgBAFAAQALAAAGAFQAGAGAAAKIAAAbIgNAAIAAgFQgDAGgLAAQgGAAgEgCgAgIAKQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQACABAEAAQACAAADgBQADgCABgDIAAgFIgJAAQgIAAAAAGg");
	this.shape_125.setTransform(308.1,163.45);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_126.setTransform(304.1,162.55);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#101828").s().p("AgXAfIAAg+IAvAAIAAAMIggAAIAAAQIAcAAIAAAMIgcAAIAAAWg");
	this.shape_127.setTransform(300.125,162.75);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#101828").s().p("AgMAYQgEgCgFgDIAFgKQACACAGACIAIABQAIAAABgEQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQgCgBgFAAIgJgDQgEAAgDgDQgDgEAAgFQAAgEADgEQADgDAFgCQAEgCAHAAIAKABIAJADIgGAKQgGgEgHAAQgDAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABAAAAABQABAAAAAAIAHACIAJACIAIADQACAEAAAEQAAAEgCAEQgDADgFADQgIACgEAAg");
	this.shape_128.setTransform(283.15,230.9);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#101828").s().p("AgNAVQgFgDgEgFQgEgFABgIQgBgGAEgGQADgFAGgEQAHgDAGAAQAIAAAFADQAIAEACAFQAEAGAAAGQAAAIgEAFQgDAFgHADQgFAEgIAAQgHAAgGgEgAgIgJQgEAFAAAEQAAAFAEAEQAEAEAEABQAFgBAEgEQADgEAAgFQAAgEgDgFQgDgDgGAAQgFAAgDADg");
	this.shape_129.setTransform(277.85,230.9);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#101828").s().p("AgFAZQgFgEAAgIIAAgTIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAATQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABAAABAAQAAABABAAIAGgCIADAKIgEACIgHABQgHAAgFgFg");
	this.shape_130.setTransform(273.05,230.4);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#101828").s().p("AgNAVQgGgCgDgGQgDgGAAgHQAAgGADgGQADgFAGgEQAHgDAGAAQAIAAAFADQAIAEACAFQADAGAAAGQAAAIgDAFQgDAFgHADQgFAEgIAAQgHAAgGgEgAgIgJQgDAEgBAFQABAGADADQAEAEAEABQAFgBAEgEQADgEABgFQgBgEgDgFQgEgDgFAAQgEAAgEADg");
	this.shape_131.setTransform(268.2,230.9);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#101828").s().p("AALAhIAAgZQAAgGgDgCQgCgDgFAAQgEAAgDADQgEADAAAGIAAAYIgOAAIAAhBIAOAAIAAAXIAHgEQADgCAFAAQAJAAAFAGQAGAFAAAKIAAAbg");
	this.shape_132.setTransform(262.075,229.975);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#101828").s().p("AgaAfIAAg+IAaAAQAIAAAGAEQAHADADAEQADAFAAAIQAAAGgDAEQgDAFgHAEQgFACgJAAIgMAAIAAARgAgMACIAMAAQAGAAADgCQADgDAAgEQAAgHgDgBQgDgDgGAAIgMAAg");
	this.shape_133.setTransform(255.875,230.15);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#101828").s().p("AALAYIAAgYQAAgGgDgDQgCgDgFAAQgEABgDADQgEADAAAGIAAAXIgOAAIAAgvIAOAAIAAAGIAHgFQADgCAFABQAJgBAFAGQAGAFAAALIAAAag");
	this.shape_134.setTransform(301.775,220.05);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#101828").s().p("AgNAVQgFgCgEgGQgEgFAAgIQAAgGAEgGQADgFAGgEQAGgDAHAAQAIAAAGADQAFADAEAGQAEAHAAAFQAAAGgEAHQgEAGgFACQgGAEgIAAQgHAAgGgEgAgIgJQgDAEAAAFQAAAGADADQADAEAFABQAGgBADgEQADgDAAgGQAAgFgDgEQgDgDgGAAQgFAAgDADg");
	this.shape_135.setTransform(295.725,220.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgCAAgEQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_136.setTransform(291.425,218.975);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#101828").s().p("AgFAZQgFgEAAgIIAAgTIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAATQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAQAAABABAAQAEAAACgCIADAKIgEACIgHABQgHAAgFgFg");
	this.shape_137.setTransform(288.05,219.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#101828").s().p("AgKAVQgHgDgDgFQgDgFAAgIQAAgGADgGQACgFAIgEQAGgDAHAAQAHAAAGADQAGAEACAGIgLAFQgDgHgHABQgFAAgDADQgEAEAAAFQAAAGAEADQADAEAFABQAHgBADgGIALAFQgCAGgGADQgFAEgIAAQgIAAgFgEg");
	this.shape_138.setTransform(283.475,220.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#101828").s().p("AgLAVQgFgCgFgGQgEgHAAgGQAAgFAEgHQAEgGAGgDQAFgDAGAAQAHAAAHADQAFADAEAGQACAGAAAGIAAAEIgjAAQAAAEAFADQADADAFAAIAGgCIAGgDIAHAIQgHAIgMAAQgIAAgGgEgAgHgKQgDACAAAFIAXAAQgBgFgEgCQgCgDgGgBQgDABgEADg");
	this.shape_139.setTransform(277.9,220.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#101828").s().p("AgaAhIAAhBIAOAAIAAAGQAFgGAKAAQAHAAAFADQAFADADAGQAEAFgBAIQABAHgEAFQgDAFgFADQgFAEgHAAQgJAAgGgGIAAAWgAgIgRQgDADgBAHQABAGADACQAEAEAEAAQAFAAADgEQAEgCAAgGQAAgHgEgDQgDgEgFAAQgFAAgDAEg");
	this.shape_140.setTransform(272.15,220.925);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#101828").s().p("AgLAYQgGgCgEgDIAFgKQADACAFACIAIABQAJAAgBgEQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQgCgBgEAAIgKgDQgDAAgEgDQgDgEABgFQgBgEADgEQADgDAFgCQAEgCAHAAIAKABIAIADIgEAKQgIgEgGAAQgEAAgCACQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAAAAAABQABAAAAAAIAHACIAJACQAGACABABQADADAAAFQAAAEgDAEQgCADgGADQgGACgFAAQgGAAgFgBg");
	this.shape_141.setTransform(266.45,220.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#101828").s().p("AALAYIAAgYQAAgGgDgDQgCgDgFAAQgEABgDADQgEADAAAGIAAAXIgOAAIAAgvIAOAAIAAAGIAHgFIAIgBQAJgBAFAGQAGAFAAALIAAAag");
	this.shape_142.setTransform(260.975,220.05);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#101828").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_143.setTransform(256.375,219.35);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#101828").s().p("AgNAfQgHgEgCgFQgDgFAAgIQAAgIADgEQADgGAGgDQAFgDAHAAQAIAAAFAGIAAgYIAOAAIAABCIgNAAIAAgGQgFAHgJAAQgHAAgFgDgAgIAAQgDADAAAGQAAAFADAEQAEAEAEAAQAFAAAEgEQAEgDAAgGQAAgHgEgCQgDgEgGAAQgEAAgEAEg");
	this.shape_144.setTransform(249.075,219.225);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#101828").s().p("AgOAfQgFgFgDgEQgDgGAAgHQAAgHADgFQADgGAFgDQAGgDAHAAQAJAAAEAGIAAgYIAPAAIAABCIgOAAIAAgGQgGAHgIAAQgHAAgGgDgAgHAAQgEACAAAHQAAAGAEADQAEAEAEAAQAFAAADgEQAEgDgBgGQABgHgEgCQgDgEgFAAQgFAAgDAEg");
	this.shape_145.setTransform(242.85,219.225);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#101828").s().p("AAUAfIgGgNIgcAAIgFANIgPAAIAcg+IANAAIAcA+gAgJAHIATAAIgKgXg");
	this.shape_146.setTransform(236.525,219.35);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#101828").s().p("AALAYIAAgYQAAgFgDgDQgDgEgEAAQgFAAgDAEQgDADAAAGIAAAXIgOAAIAAgvIAOAAIAAAGIAGgFQAEgBAFgBQAIABAGAFQAGAGAAAKIAAAag");
	this.shape_147.setTransform(291.875,142.85);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#101828").s().p("AgNAWQgFgDgFgGQgDgGAAgHQAAgGADgGQAEgFAGgEQAHgDAGAAQAHAAAHADQAHAFACAEQADAGAAAGQAAAHgDAGQgDAFgGAEQgGADgIAAQgHAAgGgDgAgIgJQgEADABAGQgBAGAEADQAEAFAEAAQAFAAAEgFQADgEAAgFQAAgFgDgEQgEgEgFABQgFgBgDAEg");
	this.shape_148.setTransform(285.8,142.9);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgDAAgDQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAAEgDACQgCACgEAAQgDAAgCgCg");
	this.shape_149.setTransform(281.475,141.775);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#101828").s().p("AgGAaQgEgFAAgJIAAgSIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABAAABAAQAAABABAAQAEgBACgBIADAKIgEACIgHABQgHAAgGgEg");
	this.shape_150.setTransform(278.15,142.4);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#101828").s().p("AgKAWQgGgDgEgGQgDgHgBgGQABgFADgHQADgFAHgEQAGgDAGAAQAIAAAGADQAFAEAEAGIgMAFQgDgGgIAAQgEgBgEAEQgDADAAAGQAAAGADADQAEAFAEAAQAIAAADgHIAMAGQgEAGgFADQgHADgHAAQgGAAgGgDg");
	this.shape_151.setTransform(273.55,142.9);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#101828").s().p("AgLAWQgHgEgDgFQgEgGAAgHQAAgGAEgGQADgFAGgEQAGgDAGAAQAHAAAGADQAGADADAGQADAFAAAHIAAAEIgjAAQAAAEAEADQAEACAFABIAGgBIAGgEIAHAIQgHAIgNAAQgIAAgFgDgAgHgLQgDACAAAGIAWAAQgBgGgDgCQgDgCgFAAQgDAAgEACg");
	this.shape_152.setTransform(268,142.9);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#101828").s().p("AgZAhIAAhBIANAAIAAAGQAFgGAJAAQAHAAAGADQAFADADAGQADAFAAAIQAAAHgDAFQgCAFgGADQgGAEgHAAQgIAAgFgGIAAAWgAgIgRQgDAEAAAGQAAAGADACQAEAEAEAAQAFAAAEgEQADgDAAgFQAAgGgDgEQgEgEgFAAQgFAAgDAEg");
	this.shape_153.setTransform(262.225,143.725);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#101828").s().p("AgMAYQgGgCgDgDIAEgKIAJAEIAIABQAJAAgBgEQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAQgCgCgEABIgKgDQgDgBgEgCQgDgDAAgGQAAgDACgFQADgDAGgCQAEgCAGAAIAKABIAJADIgEAKQgIgEgHABQgDAAgCABQgBAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAABABAAIAGACIAKACQAEACADABQADADAAAFQAAAFgDADQgBADgHADQgHACgEAAIgMgBg");
	this.shape_154.setTransform(256.55,142.9);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#101828").s().p("AALAYIAAgYQAAgFgDgDQgDgEgEAAQgFAAgDAEQgDADAAAGIAAAXIgOAAIAAgvIAOAAIAAAGIAGgFQAEgBAFgBQAIABAGAFQAGAGAAAKIAAAag");
	this.shape_155.setTransform(251.075,142.85);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#101828").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_156.setTransform(246.475,142.15);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#101828").s().p("AgGAaQgEgFAAgJIAAgSIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABAAABAAQAAABABAAQAEgBACgBIADAKIgEACIgHABQgIAAgFgEg");
	this.shape_157.setTransform(288.15,131.6);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#101828").s().p("AgKAWQgGgDgEgGQgEgHAAgGQAAgFAEgHQADgFAHgEQAGgDAGAAQAIAAAGADQAGAEADAGIgLAFQgEgGgIAAQgEgBgEAEQgDADAAAGQAAAGADADQAFAFADAAQAHAAAFgHIALAGQgDAGgGADQgFADgJAAQgGAAgGgDg");
	this.shape_158.setTransform(283.55,132.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#101828").s().p("AgSATQgGgGAAgKIAAgbIAPAAIAAAZQgBALAKAAQAEAAAEgDQACgDAAgGIAAgYIAPAAIAAAwIgOAAIAAgGQgDAEgDABQgEACgDAAQgJAAgHgGg");
	this.shape_159.setTransform(277.7,132.125);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#101828").s().p("AgNAfQgGgFgDgEQgDgFAAgIQAAgHADgFQADgGAGgDQAFgDAHAAQAIAAAGAGIAAgYIANAAIAABCIgNAAIAAgGQgGAHgIAAQgHAAgFgDgAgHAAQgEACAAAHQAAAGAEADQADAEAFAAQAFAAADgEQADgDABgGQgBgHgDgCQgDgEgFAAQgFAAgDAEg");
	this.shape_160.setTransform(271.35,131.225);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#101828").s().p("AALAYIAAgYQAAgFgDgDQgDgEgEAAQgFAAgDAEQgDADAAAGIAAAXIgOAAIAAgvIAOAAIAAAGIAGgFQAEgBAFgBQAIABAGAFQAGAGAAAKIAAAag");
	this.shape_161.setTransform(265.275,132.05);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#101828").s().p("AgMAWQgGgDgEgGQgDgGAAgHQAAgGADgGQADgFAHgEQAFgDAHAAQAIAAAFADQAHAFADAEQADAGAAAGQAAAHgDAGQgDAFgHAEQgFADgIAAQgHAAgFgDgAgIgJQgDADgBAGQABAGADADQAEAFAEAAQAFAAAEgFQADgEABgFQgBgFgDgEQgEgEgFABQgEgBgEAEg");
	this.shape_162.setTransform(259.2,132.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#101828").s().p("AgMAcQgJgEgEgHQgEgHAAgKQAAgIAEgIQAFgHAIgEQAIgFAIAAQAJAAAGAEQAHADAEAFIgJAJQgHgIgJAAQgFAAgFACQgEADgDAFQgCAEAAAFQAAAGACAEQADAFAEADQAFACAFAAQAJAAAHgHIAJAIQgEAGgHADQgIADgHAAQgKgBgGgEg");
	this.shape_163.setTransform(253.175,131.35);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#101828").s().p("AgLAWQgGgDgEgGQgEgHABgGQgBgFAEgHQAEgGAFgDQAHgDAGAAQAHAAAFADQAHADACAGQADAGAAAGIAAAEIgjAAQABAEAEADQAEADAEgBIAHgBIAFgDIAHAIQgGAIgNAAQgJAAgFgDgAgGgLQgDADgCAEIAYAAQgBgEgDgDQgEgDgEAAQgEAAgDADg");
	this.shape_164.setTransform(243.55,63.1);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#101828").s().p("AgOAfQgFgFgDgEQgDgFAAgIQAAgIADgEQADgGAFgDQAGgDAHAAQAJAAAEAGIAAgYIAPAAIAABCIgOAAIAAgGQgGAHgIAAQgHAAgGgDgAgHAAQgEACAAAHQAAAGAEADQACAEAGAAQAEAAAEgEQAEgDgBgGQABgHgEgCQgEgEgEAAQgGAAgCAEg");
	this.shape_165.setTransform(237.45,62.225);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#101828").s().p("AgMAWQgHgDgDgGQgEgFAAgIQAAgGAEgGQACgFAIgEQAFgDAHAAQAIAAAGADQAHAEADAFQACAGAAAGQAAAHgCAGQgEAGgGADQgGADgIAAQgHAAgFgDgAgIgJQgDAFAAAEQAAAFADAFQAEADAEAAQAFAAAEgDQAEgEAAgGQAAgFgEgEQgDgDgGgBQgFABgDADg");
	this.shape_166.setTransform(231.55,63.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#101828").s().p("AAWAgIAAglIgTAeIgFAAIgTgdIAAAkIgNAAIAAg+IALAAIAYAmIAWgmIANAAIAAA+g");
	this.shape_167.setTransform(224.3,62.35);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#101828").s().p("AgMAWQgFgDgFgGQgCgGAAgHQAAgGACgGQAEgGAGgDQAGgDAGAAQAHAAAGADQAGADADAGQAEAGgBAGIAAAEIgkAAQABAEAEADQAEADAFgBIAGgBIAFgDIAIAIQgHAIgNAAQgIAAgGgDgAgHgLQgDADgBAEIAXAAQgBgFgDgCQgDgDgFAAQgDAAgEADg");
	this.shape_168.setTransform(214.65,63.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#101828").s().p("AALAZIAAgZQAAgGgDgDQgCgCgFAAQgEgBgDAEQgEADAAAFIAAAZIgOAAIAAgwIAOAAIAAAGIAHgFIAIgCQAJAAAFAGQAGAFAAALIAAAbg");
	this.shape_169.setTransform(208.625,63.05);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgCAAgEQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_170.setTransform(204.175,61.975);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#101828").s().p("AANAiIAAhCIAOAAIAABCgAgTAiIAAgkIgHAAIAAgKIAHAAIAAgDQAAgIAFgFQAFgFAJAAIAFABIAFACIgEAKQgDgCgDAAQgFAAAAAHIAAADIALAAIAAAKIgLAAIAAAkg");
	this.shape_171.setTransform(199.425,62.125);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#101828").s().p("AgKAiIAAgkIgHAAIAAgKIAHAAIAAgDQAAgIAFgFQAEgFAJAAIAFABIAGACIgEAKIgGgCQgGAAAAAHIAAADIAMAAIAAAKIgMAAIAAAkg");
	this.shape_172.setTransform(195.05,62.125);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#101828").s().p("AgRAcQgIgFgEgGQgFgIABgJQgBgIAFgIQAEgHAIgEQAJgFAIABQAKgBAHAFQAJAEAEAHQAFAIgBAIQABAJgFAIQgEAGgJAFQgGAFgLAAQgKAAgHgFgAgJgRQgEACgEAFQgCAFAAAFQAAAFACAFQAEAGAEABQAEADAFABQAFgBAFgDQAFgCACgFQADgFAAgFQAAgFgDgFQgCgEgFgDQgFgCgFAAQgEAAgFACg");
	this.shape_173.setTransform(189.35,62.35);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#101828").s().p("AgMAYQgFgBgEgEIAFgKQADACAFACIAIABQAIAAABgEQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQgCgCgEABIgKgDQgDAAgEgDQgCgEAAgFQAAgFACgDQADgDAFgCQAEgCAGAAIALABIAIADIgEAKQgHgDgIAAQgCAAgDABQgBAAAAABQgBAAAAAAQAAABAAAAQAAABgBAAQABABAAAAQAAAAAAABQAAAAABAAQAAABABAAIAHACIAJACQAGACABABQADADAAAFQAAAFgDADQgCADgGADQgGACgFAAQgGAAgGgBg");
	this.shape_174.setTransform(183,177.9);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#101828").s().p("AgLAWQgHgDgDgGQgDgFgBgIQABgGADgGQADgFAGgEQAGgDAGAAQAIAAAFADQAGADADAGQADAFABAHIgBAEIgjAAQAAADAEAEQAEADAEAAIAHgBIAGgEIAHAIQgHAIgNAAQgHAAgGgDgAgHgKQgCABgBAGIAWAAQAAgFgEgCQgDgDgFAAQgEAAgDADg");
	this.shape_175.setTransform(177.8,177.9);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#101828").s().p("AgFAZQgFgEAAgJIAAgSIgHAAIAAgLIAHAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABAAAAIAFACQAEAAACgCIAEAKIgGACIgGABQgIAAgEgFg");
	this.shape_176.setTransform(173.1,177.4);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#101828").s().p("AgOAXQgEgDgCgDQgCgCAAgFQAAgHAFgDQAFgDALAAIAKAAQAAgFgDgCQgDgDgEAAIgIACQgDAAgDACIgFgJQADgDAGgBQAGgCAFAAQAKAAAHAFQAGAGAAALIAAAaIgNAAIAAgGQgEAHgKAAQgEAAgGgCgAgIAJQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQACABAEABQADAAACgCQADgCABgDIAAgFIgJAAQgIAAAAAFg");
	this.shape_177.setTransform(168.275,177.9);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_178.setTransform(164.3,176.975);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#101828").s().p("AgaAhIAAhBIAOAAIAAAGQAFgGAKAAQAHAAAFADQAFACAEAHQACAFAAAIQAAAHgCAFQgEAGgFACQgFAEgHAAQgJAAgFgGIAAAWgAgIgRQgDADAAAHQAAAGADACQAEAEAEAAQAFAAAEgEQADgCAAgGQAAgGgDgEQgDgEgGAAQgFAAgDAEg");
	this.shape_179.setTransform(160,178.725);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#101828").s().p("AAbAYIAAgYQAAgGgDgCQgCgEgEAAQgFABgDADQgDADAAAGIAAAXIgNAAIAAgYQAAgMgJAAQgFABgDADQgDADAAAGIAAAXIgOAAIAAgvIANAAIAAAGQADgDAEgCQAEgCAFABQAFAAAEABQACACAEAFQADgEAEgDQAEgBAGAAQAJAAAFAFIABAAQAFAFAAALIAAAag");
	this.shape_180.setTransform(152.025,177.85);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#101828").s().p("AgMAWQgGgDgDgGQgEgFABgIQgBgGAEgGQADgFAGgEQAGgDAGAAQAHAAAGADQAGADADAGQAEAFgBAHIAAAEIgkAAQABADAEAEQAEADAFAAIAGgBIAFgEIAIAIQgHAIgNAAQgIAAgGgDgAgGgKQgEABgBAGIAXAAQgBgGgDgBQgDgDgEAAQgFAAgCADg");
	this.shape_181.setTransform(144.45,177.9);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#101828").s().p("AgGAfIAAgxIgVAAIAAgNIA2AAIAAANIgUAAIAAAxg");
	this.shape_182.setTransform(139.3,177.15);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#101828").s().p("AgOAfQgGgFgCgEQgDgFAAgIQAAgIADgEQADgGAFgDQAGgDAHAAQAIAAAFAGIAAgYIAOAAIAABCIgNAAIAAgGQgGAHgIAAQgHAAgGgDgAgIAAQgDACAAAHQAAAGADADQAEAEAEAAQAGAAADgEQADgDAAgGQAAgHgDgCQgDgEgGAAQgEAAgEAEg");
	this.shape_183.setTransform(180.975,166.225);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#101828").s().p("AgLAWQgGgDgEgGQgEgGAAgHQAAgGAEgGQAEgGAFgDQAGgDAGAAQAHAAAGADQAGADADAGQADAGABAGIgBAEIgjAAQAAAEAEADQAEADAEAAIAHgBIAGgEIAHAIQgHAIgNAAQgIAAgFgDgAgHgKQgDACAAAFIAWAAQgBgGgDgBQgDgDgFAAQgDAAgEADg");
	this.shape_184.setTransform(175.2,167.1);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#101828").s().p("AgGAZQgEgEAAgJIAAgSIgHAAIAAgLIAHAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAABAAABQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABQABAAAAAAQABAAABAAQAAABABAAQADAAADgCIADAKIgFACIgGABQgHAAgGgFg");
	this.shape_185.setTransform(170.5,166.6);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgDAAgDQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_186.setTransform(167.225,165.975);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#101828").s().p("AAbAYIAAgYQAAgGgDgCQgCgEgEAAQgFABgDADQgDADAAAGIAAAXIgNAAIAAgYQAAgMgJAAQgFABgDADQgDADAAAGIAAAXIgOAAIAAgvIANAAIAAAGQADgDAEgCQAEgCAFABQAFAAAEABQACACAEAFQADgEAEgDQAEgBAGAAQAJAAAFAFQAGAFAAALIAAAag");
	this.shape_187.setTransform(161.175,167.05);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgDAAgDQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_188.setTransform(155.075,165.975);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_189.setTransform(152.35,166.175);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#101828").s().p("AALAYIAAgYQAAgFgDgDQgDgEgEAAQgFABgDADQgDADAAAGIAAAXIgOAAIAAgvIAOAAIAAAGIAGgFQAEgCAFABQAIAAAGAFQAGAFAAALIAAAag");
	this.shape_190.setTransform(147.925,167.05);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#101828").s().p("AgUAYQgHgHAAgNIAAgjIAOAAIAAAiQAAARANAAQAHAAADgFQAEgDAAgJIAAgiIAOAAIAAAjQAAANgHAHQgIAIgNAAQgMAAgIgIg");
	this.shape_191.setTransform(141.25,166.4);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#101828").s().p("AgMAXQgFgBgEgCIAFgKQACABAGACIAIABQAIAAAAgEQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQgDgBgDgBIgKgCQgEgBgDgCQgDgDAAgGQAAgEADgDQACgDAGgDQAEgCAHAAIAKABIAIADIgEAKQgIgEgGABQgEgBgCACQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABAAAAABQABAAAAAAIAHACIAJACQAFACACABQADADAAAGQAAADgDAEQgCADgGADQgHACgEAAg");
	this.shape_192.setTransform(148.225,279.9);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#101828").s().p("AgMAWQgFgDgEgGQgDgFAAgIQAAgHADgFQADgFAGgEQAGgDAGAAQAIAAAFADQAGADAEAGQACAFAAAHIAAAEIgkAAQACAEAEADQADACAFABIAGgBIAFgEIAIAIQgHAIgNAAQgHAAgHgDgAgGgLQgEADgBAEIAYAAQgBgEgEgDQgDgCgFAAQgDAAgDACg");
	this.shape_193.setTransform(143,279.9);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#101828").s().p("AgGAaQgEgFAAgJIAAgTIgHAAIAAgKIAHAAIAAgMIANAAIAAAMIAMAAIAAAKIgMAAIAAATQAAABAAABQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABQABAAAAAAQABAAABAAQAAAAABABQADgBACgBIAFAKIgGACIgGABQgIAAgFgEg");
	this.shape_194.setTransform(138.35,279.4);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#101828").s().p("AgOAXQgEgDgCgDQgCgCAAgFQAAgHAFgDQAGgEAKAAIAKAAQAAgEgDgDQgDgCgEAAIgIABQgEABgDACIgFgJQAFgDAFgBIALgCQAMAAAFAFQAGAGAAAKIAAAbIgNAAIAAgGQgEAHgKAAQgFAAgFgCgAgIAKQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQADACAEgBQADAAACgBQACgCACgDIAAgFIgJAAQgIAAAAAGg");
	this.shape_195.setTransform(133.5,279.9);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#101828").s().p("AgOAfQgGgFgCgEQgDgFAAgIQAAgIADgEQADgGAFgDQAGgDAHAAQAIAAAFAGIAAgYIAOAAIAABCIgNAAIAAgGQgGAHgIAAQgHAAgGgDgAgIAAQgDACAAAHQAAAGADADQAEAEAEAAQAFAAAEgEQAEgEAAgFQAAgGgEgDQgDgEgGAAQgEAAgEAEg");
	this.shape_196.setTransform(127.575,279.025);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#101828").s().p("AgZAhIAAhBIANAAIAAAGQAFgGAJAAQAIAAAEADQAGADADAGQAEAFAAAIQAAAHgEAFQgDAFgGADQgEAEgIAAQgIAAgGgGIAAAWgAgIgRQgEADAAAHQAAAGAEACQAEAEAEAAQAFAAAEgEQADgCAAgGQAAgHgDgDQgEgEgFAAQgFAAgDAEg");
	this.shape_197.setTransform(121.7,280.725);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#101828").s().p("AgUAYQgIgHAAgOIAAgiIAPAAIAAAiQABARANAAQAHAAADgFQADgEAAgIIAAgiIAPAAIAAAiQAAAOgIAHQgHAIgOAAQgNAAgHgIg");
	this.shape_198.setTransform(114.85,279.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#101828").s().p("AgMAWQgGgDgDgGQgEgFABgIQAAgGACgGQAEgGAGgDQAGgDAGAAQAHAAAGADQAGADADAGQADAFAAAHIAAAEIgkAAQABAEAEADQAEACAFAAIAGAAIAFgEIAIAIQgHAIgNAAQgIAAgGgDgAgGgLQgDADgCAEIAXAAQgBgEgDgDQgDgCgEAAQgFAAgCACg");
	this.shape_199.setTransform(151.3,269.1);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#101828").s().p("AAbAZIAAgZQAAgFgCgDQgDgDgFAAQgFAAgCADQgDADAAAGIAAAYIgNAAIAAgZQAAgMgKABQgEAAgDADQgDADAAAGIAAAYIgOAAIAAgwIANAAIAAAGQACgDAFgCQAEgBAFgBQAFAAAEACQADADADADQADgDAEgDQAEgCAGAAQAKABAEAFQAGAGAAAKIAAAbg");
	this.shape_200.setTransform(143.7,269.05);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#101828").s().p("AgGAjIAAgvIANAAIAAAvgAgFgVQgDgDAAgDQAAgDADgCQACgCADAAQAEAAACACQADACAAADQAAAEgDACQgCACgEAAQgCAAgDgCg");
	this.shape_201.setTransform(137.575,267.975);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#101828").s().p("AgGAgIAAgzIgUAAIAAgLIA1AAIAAALIgUAAIAAAzg");
	this.shape_202.setTransform(133.575,268.35);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#101828").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_203.setTransform(126.9,268.175);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#101828").s().p("AgOAXQgEgDgCgDQgCgDAAgEQAAgGAFgEQAGgDAKgBIAKAAQAAgEgDgDQgDgCgEAAIgHABQgFABgCACIgFgJQAEgDAFgBQAGgCAFAAQAMAAAFAFQAGAGAAAKIAAAbIgNAAIAAgGQgEAHgKAAIgKgCgAgIAKQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQADACADgBQADAAACgCQADgBABgDIAAgFIgJAAQgIAAAAAGg");
	this.shape_204.setTransform(122.6,269.1);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#101828").s().p("AgLAWQgGgDgEgGQgEgHAAgGQAAgFAEgHQAEgGAFgDQAGgDAGAAQAHAAAGADQAGADADAGQAEAGAAAGIgBAEIgjAAQAAAEAEADQAEACAEAAIAHAAIAGgEIAHAIQgHAIgNAAQgIAAgFgDgAgHgLQgDADgBAEIAXAAQgBgEgDgDQgDgCgFAAQgDAAgEACg");
	this.shape_205.setTransform(117.275,269.1);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#101828").s().p("AAMAgIgMgSIgMAAIAAASIgPAAIAAg+IAbAAQAIAAAGACQAHAEACAFQAEAFAAAGQAAAHgEAFQgDAEgGADIAOAVgAgMACIAMAAQAFAAAEgCQADgCAAgGQAAgGgDgCQgEgDgFAAIgMAAg");
	this.shape_206.setTransform(111.35,268.35);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#101828").s().p("AgMAYIAAgBQgEAAgFgDIAFgKQADACAFABIAIABQAIAAABgEQAAgBgBAAQAAAAAAgBQAAAAgBAAQAAgBgBAAIgQgEQgDAAgEgDQgCgCAAgGQAAgFACgDQADgEAFgCQAEgCAGAAIALABIAIADIgEAKQgGgDgJAAQgCAAgDABQgBABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAABAAIAHACIAJACQAFABACACQADADAAAGQAAAEgDAEQgDADgFACQgEACgHAAIgMgBg");
	this.shape_207.setTransform(64.65,219.325);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#101828").s().p("AgLAVQgHgDgDgGQgDgEgBgIQAAgGAEgGQAEgGAFgDQAGgDAGAAQAHAAAGADQAGADADAFQADAGABAHIgBAEIgjAAQAAAEAEADQAEADAEgBIAHgBIAGgDIAHAIQgHAIgNAAQgHAAgGgEgAgHgLQgCADgBAEIAWAAQgBgEgDgDQgEgCgEgBQgDABgEACg");
	this.shape_208.setTransform(59.45,219.35);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#101828").s().p("AgGAkIAAgwIANAAIAAAwgAgFgVQgDgCAAgDQAAgDADgDQACgCADgBQAEABACACQADACAAADQAAAEgDACQgCACgEABQgDgBgCgCg");
	this.shape_209.setTransform(55.225,218.2);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#101828").s().p("AgGAaQgEgFAAgIIAAgTIgIAAIAAgLIAIAAIAAgMIANAAIAAAMIAMAAIAAALIgMAAIAAASQAAAEACABQAAABAAAAQABAAAAAAQABABABAAQAAAAABAAQAEAAACgCIADAKIgEACIgHABQgIAAgFgEg");
	this.shape_210.setTransform(51.9,218.825);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#101828").s().p("AgOAZIAAgwIAOAAIAAAGQAAgDAGgCQAEgCAFAAIAAAOIgDgBQgFAAgFADQgCAFAAAEIAAAYg");
	this.shape_211.setTransform(48.1,219.3);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#101828").s().p("AgLAVQgGgCgEgHQgDgFAAgHQAAgFADgHQAEgGAFgDQAGgDAGAAQAHAAAHADQAFADAEAFQACAHAAAGIAAAEIgjAAQAAAEAFADQADADAFgBIAGgBIAGgDIAIAIQgJAIgLAAQgHAAgHgEgAgGgLQgEADgBAEIAYAAQgBgEgEgDQgDgCgFgBQgDABgDACg");
	this.shape_212.setTransform(43.1,219.35);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#101828").s().p("AgZAhIAAhBIANAAIAAAGQAFgGAKAAQAGAAAFADQAFACAEAGQADAGAAAIQAAAHgDAFQgEAGgFACQgFADgGAAQgJAAgFgFIAAAWgAgIgRQgDADgBAHQABAGADACQAEAEAEAAQAFAAAEgEQADgCAAgGQAAgGgDgEQgEgEgFAAQgEAAgEAEg");
	this.shape_213.setTransform(37.35,220.175);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#101828").s().p("AgNAWQgFgDgEgGQgEgGAAgHQAAgGAEgGQAEgGAFgDQAGgDAHAAQAIAAAGADQAFADAEAGQAEAGAAAGQAAAHgEAGQgEAGgFADQgGADgIAAQgHAAgGgDgAgIgJQgDAEAAAFQAAAGADAEQADADAFAAQAGAAADgDQADgEAAgGQAAgFgDgEQgDgDgGAAQgFAAgDADg");
	this.shape_214.setTransform(31.125,219.325);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#101828").s().p("AgOAZIAAgwIANAAIAAAGQABgDAFgCQAEgCAGAAIAAAOIgDgBQgFAAgFADQgCAFAAAEIAAAYg");
	this.shape_215.setTransform(26.55,219.3);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#101828").s().p("AgaAgIAAg+IAaAAQAIAAAGACQAGADAEAFQADAFAAAHQAAAHgDAFQgDAEgHAEQgGACgIAAIgMAAIAAASgAgMADIAMAAQAGAAADgDQADgCAAgGQAAgFgDgDQgEgCgFgBIgMAAg");
	this.shape_216.setTransform(21.375,218.6);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#101828").s().p("AgOAfQgFgDgDgGQgDgGAAgHQAAgHADgFQADgGAFgDQAGgDAHAAQAIAAAFAGIAAgYIAOAAIAABCIgNAAIAAgFQgFAGgJAAQgHAAgGgDgAgIAAQgDADAAAGQAAAGADAEQAEADAEAAQAGAAADgDQAEgFAAgFQAAgFgEgEQgDgDgGAAQgEAAgEADg");
	this.shape_217.setTransform(56.025,207.625);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#101828").s().p("AgNAXQgFgCgCgDQgCgDAAgFQAAgHAFgDQAGgDAKAAIAKAAQAAgFgDgCQgCgDgFAAIgIACIgGADIgFgKQAFgDAFgBIAKgCQALAAAGAFQAGAGAAALIAAAaIgNAAIAAgGQgFAHgJAAQgFAAgEgCgAgJAKQAAAAABABQAAABAAAAQAAAAABABQAAAAABABQACACAEAAIAFgCQACgBACgEIAAgFIgJAAQgJAAAAAGg");
	this.shape_218.setTransform(50.1,208.525);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#101828").s().p("AgMAWQgHgEgDgFQgDgFgBgIQABgHADgFQADgGAHgDQAFgDAHAAQAHAAAHADQAGAEADAFQADAFAAAHQAAAIgDAFQgDAFgGAEQgHADgHAAQgHAAgFgDgAgIgJQgEAFABAEQgBAFAEAFQADADAFAAQAFAAAEgDQADgFAAgFQAAgEgDgFQgEgDgFAAQgFAAgDADg");
	this.shape_219.setTransform(44.6,208.525);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#101828").s().p("AgGAiIAAhDIANAAIAABDg");
	this.shape_220.setTransform(40.3,207.6);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#101828").s().p("AgZAhIAAhBIANAAIAAAGQAFgGAJAAQAHAAAFADQAGADADAFQADAGAAAIQAAAHgDAFQgDAFgGADQgFADgHAAQgIAAgFgFIAAAWgAgIgRQgEAEAAAGQAAAFAEADQADAEAFAAQAFAAAEgEQADgDAAgFQAAgGgDgEQgEgEgFAAQgFAAgDAEg");
	this.shape_221.setTransform(36.025,209.375);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#101828").s().p("AgUAZQgHgIAAgOIAAgiIAOAAIAAAiQAAAQANAAQAHAAADgDQAEgEAAgJIAAgiIAOAAIAAAiQAAAOgHAIQgIAHgNAAQgMAAgIgHg");
	this.shape_222.setTransform(29.2,207.85);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#101828").s().p("AgJDfIAAm9IATAAIAAG9g");
	this.shape_223.setTransform(392.8,172.45);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#101828").s().p("AjeLqQhchdAAiDIgB1OIAUgBIABVPQAAB7BWBWQBXBXB6AAQB6AABXhXQBWhWAAh7IAAlrIAUAAIAAFrQAACDhcBdQhdBciCAAQiCAAhdhcg");
	this.shape_224.setTransform(130.775,169.25);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#101828").s().p("AC1CSQhrhrAAiVIAAgSQgfBNhEAwQhHAvhWAAQhyAAhRhQQhRhRAAhzIAAgSIAUAAIAAASQAABrBLBLQBLBKBqAAQBqAABMhKQBKhLAAhrIAAgUIAUAAIAAAUIgBADIABAAIAAB3QAACNBlBlQBlBlCOgBIATAAIACAUIgVAAQiXAAhqhqg");
	this.shape_225.setTransform(313.625,261.25);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#101828").s().p("AgJg+IATAAIAAB8IgTABg");
	this.shape_226.setTransform(464.225,185.45);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#101828").s().p("AgJAyIAAhjIATAAIAABjg");
	this.shape_227.setTransform(392.8,245.125);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#101828").s().p("Ai1CtIACgVIATADIgBATgAixCEIAEgUIAUAEIgEATgAioBcIAGgUIATAHIgGASgAiaA1IAIgTIASAJIgIASgAiJAQIALgRIARAKIgKARgAhzgSIAMgQIAQAMIgMAQgAhagyQAGgHAJgIIAOAOIgOAOgAg9hPIAQgNIANAPIgPANgAgdhpIASgLIAKARIgQAKgAAFh/IASgJIAJASIgRAJgAAqiRIATgHIAHATIgSAHgABRieIAUgGIAEAUIgSAFgAB5ioIAUgCIADATIgUADgACiisIAUgBIAAAUIgTABg");
	this.shape_228.setTransform(52.275,68.375);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#101828").s().p("ACnC/IACgTIATAAIgBAUIgUgBgAB+C7IAEgVIATAEIgCATgABWCxIAGgUIATAFIgFAUgAAwCjIAIgTIASAIIgHASgAALCRIAKgSIARAJIgJASgAgXB7IAMgQIAPAKIgKASgAg3BiIANgPIAPAMIgMAQgAhVBGIAPgPIAOAPIgOAOgAhvAlIAQgLIAMAPIgPANgAiGADIASgJIAKAQIgRALgAiZggIATgIIAIARIgSAJgAiohGIATgHIAHATIgTAHgAiyhuIATgEIAFATIgTAFgAi5iXIAUgBIADATIgUADgAi7i/IAUAAIABATIgUABg");
	this.shape_229.setTransform(109.625,240.7);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#101828").s().p("Aj7EPIAAgUIATAAQCsAAB4h5QB5h5gBiqIAAhGIgkAkIgOgOIA8g9IA+A+IgNAPIgngmIAABGQABCyiAB/Qh+B/izAAg");
	this.shape_230.setTransform(529.7,205.425);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#101828").s().p("AgNADIAMgQIAPALIgLAQg");
	this.shape_231.setTransform(482.875,224.35);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#101828").s().p("AgNABIANgOIAOAMIgMAPg");
	this.shape_232.setTransform(479.675,221.95);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#101828").s().p("AgNAEIAKgRIAQAKIgJARg");
	this.shape_233.setTransform(486.3,226.425);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#101828").s().p("AgNAAIANgNIAOANIgOAOg");
	this.shape_234.setTransform(476.7,219.275);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#101828").s().p("AgKAJIADgTIASACIgCATg");
	this.shape_235.setTransform(501.45,231.225);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#101828").s().p("AgLAIIAFgTIASAEIgEATg");
	this.shape_236.setTransform(497.525,230.575);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#101828").s().p("AgMAHIAHgSIASAFIgGASg");
	this.shape_237.setTransform(493.65,229.55);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#101828").s().p("AgMAFIAIgRIARAIIgHARg");
	this.shape_238.setTransform(489.9,228.15);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#101828").s().p("AgMgGIASgGIAGASIgRAHg");
	this.shape_239.setTransform(466.3,202.475);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#101828").s().p("AgLgHIATgEIAEASIgTAFg");
	this.shape_240.setTransform(465.25,198.6);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#101828").s().p("AgKgIIASgCIADASIgTADg");
	this.shape_241.setTransform(464.55,194.675);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#101828").s().p("AgNgCIAQgLIALAPIgQAMg");
	this.shape_242.setTransform(471.6,213.15);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#101828").s().p("AgNgBIAOgMIANAOIgOANg");
	this.shape_243.setTransform(474,216.35);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#101828").s().p("AgMgDIAQgKIAKAQIgQALg");
	this.shape_244.setTransform(469.5,209.775);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#101828").s().p("AgMgFIARgHIAIAQIgRAJg");
	this.shape_245.setTransform(467.725,206.2);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#101828").s().p("ACyEIIAOgOIAmAmIAAhDQAAjaibiaQiZiajaAAIgDAAIAAgUIADAAQDiAACgChQCgCgAADhIAABDIAkglIAOAPIg8A8g");
	this.shape_246.setTransform(244.775,48.3);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#101828").s().p("ABVDyIAOgOIAmAmIAAjOQAAiNhlhlQhkhliOAAIAAgUQCWAABqBrQBrBqAACWIAADOIAkgkIAOANIg8A9g");
	this.shape_247.setTransform(448.975,66.05);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#101828").s().p("AgMADIAJgPIARAJIgKARg");
	this.shape_248.setTransform(388.05,267.9);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#101828").s().p("AgNACIALgPIAQALIgMAQg");
	this.shape_249.setTransform(385.85,271.25);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#101828").s().p("AgMAEIAIgQIARAHIgIASg");
	this.shape_250.setTransform(389.85,264.35);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#101828").s().p("AgNAAIANgNIAOANIgOAOg");
	this.shape_251.setTransform(383.3,274.3);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#101828").s().p("AgKAJIACgTIATABIgCAUg");
	this.shape_252.setTransform(392.725,252.775);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#101828").s().p("AgMAGIAGgRIASAFIgGASg");
	this.shape_253.setTransform(391.25,260.6);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#101828").s().p("AgLAHIAEgSIATAEIgEATg");
	this.shape_254.setTransform(392.2,256.725);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#101828").s().p("AgNAAIAOgNIANAOIgOANg");
	this.shape_255.setTransform(380.4,277.05);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#101828").s().p("AgKgIIASgCIADASIgTADg");
	this.shape_256.setTransform(362.425,285.175);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#101828").s().p("AgLgGIASgFIAFASIgTAFg");
	this.shape_257.setTransform(366.35,284.375);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#101828").s().p("AgNgCIAPgLIAMAPIgQAMg");
	this.shape_258.setTransform(377.225,279.475);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#101828").s().p("AgMgFIASgHIAHARIgSAIg");
	this.shape_259.setTransform(370.15,283.15);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#101828").s().p("AgNgDQAJgEAHgFIAKAQIgRAKg");
	this.shape_260.setTransform(373.8,281.5);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_261.setTransform(322,229);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_262.setTransform(322,233);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_263.setTransform(322,221);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#101828").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_264.setTransform(322,225);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#101828").s().p("AgMgFIATgHIAGASIgSAHg");
	this.shape_265.setTransform(196.15,20.125);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#101828").s().p("AgNgDIARgKIAJARIgPAJg");
	this.shape_266.setTransform(188.95,23.5);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#101828").s().p("AgMgEIARgIIAIARIgQAIg");
	this.shape_267.setTransform(192.475,21.675);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#101828").s().p("AgNgCIAQgLIALAQIgPALg");
	this.shape_268.setTransform(185.525,25.575);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#101828").s().p("AgNgBIAPgMIAMAPIgOAMg");
	this.shape_269.setTransform(182.3,27.9);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#101828").s().p("AgNAAIAOgNIANAOIgOANg");
	this.shape_270.setTransform(179.2,30.45);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#101828").s().p("AgKgIIATgCIABATIgSABg");
	this.shape_271.setTransform(211.75,16.8);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#101828").s().p("AgKgIIATgCIACASIgSADg");
	this.shape_272.setTransform(207.775,17.225);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#101828").s().p("AgLgGIASgFIAGASIgTAFg");
	this.shape_273.setTransform(199.95,18.85);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#101828").s().p("AgLgGIAAgBIATgEIAEATIgSAEg");
	this.shape_274.setTransform(203.825,17.875);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#101828").s().p("AgMAHIAHgTIASAHQgEAJgCAJg");
	this.shape_275.setTransform(164.075,53.625);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#101828").s().p("AgKAJIADgUIASAEIgDASg");
	this.shape_276.setTransform(162.15,61.4);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#101828").s().p("AgKAKIACgUIATADIgCASg");
	this.shape_277.setTransform(161.65,65.35);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#101828").s().p("AgNABIANgOIAOANIgOAOg");
	this.shape_278.setTransform(176.35,33.225);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#101828").s().p("AgJC+IAAl7IATABIAAF6g");
	this.shape_279.setTransform(161.425,87.3);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#101828").s().p("AgLAIIAFgTIASAFIgFASg");
	this.shape_280.setTransform(162.975,57.475);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#101828").s().p("AgMAGIAIgSIARAIIgIARg");
	this.shape_281.setTransform(165.45,49.875);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#101828").s().p("AgNACIAAAAIANgPIAOANIgMAOg");
	this.shape_282.setTransform(173.675,36.2);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#101828").s().p("AgNADIAMgQIAPALIgLAQg");
	this.shape_283.setTransform(171.25,39.4);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#101828").s().p("AgNAFIAJgRIARAJQgEAHgFAKg");
	this.shape_284.setTransform(167.15,46.25);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#101828").s().p("AgNAEIALgRIAQALIgLAQg");
	this.shape_285.setTransform(169.075,42.725);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#101828").s().p("AiaCuIAAgzQABh7BWhWQBXhXB6AAIANAAIgBAUIgMAAQhyAAhQBRQhRBQAABzIAAAzg");
	this.shape_286.setTransform(57.25,75.225);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#101828").s().p("AgNgBIAPgMIAMARIgQAKg");
	this.shape_287.setTransform(95.35,71.45);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#101828").s().p("AgMgFIASgHIAGATIgSAGg");
	this.shape_288.setTransform(98.85,78.625);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#101828").s().p("AgMgDIARgJIAJARIgSAIg");
	this.shape_289.setTransform(97.35,74.925);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#101828").s().p("AgLgHIATgDIAEATIgUACIgDgSg");
	this.shape_290.setTransform(99.8,82.5);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#101828").s().p("AgNAAIAOgNIANAOIgOANg");
	this.shape_291.setTransform(92.9,68.325);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#101828").s().p("AgMAFIAHgRIASAIIgJARg");
	this.shape_292.setTransform(83.325,61.325);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#101828").s().p("AgKAJIACgTIATADIgDASg");
	this.shape_293.setTransform(75.675,59.075);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#101828").s().p("AgLAHIAEgSIATAFIgGASg");
	this.shape_294.setTransform(79.575,59.925);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#101828").s().p("AgNABIAMgOIAPANIgOAOg");
	this.shape_295.setTransform(90.05,65.55);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#101828").s().p("AgNAEIAKgRIARALIgLAQg");
	this.shape_296.setTransform(86.825,63.175);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#101828").s().p("Ai1CtIACgUIAUABIgCAUgAiwCEIADgUIATAFIgDASgAioBcIAGgUIATAHIgFATgAibA1IAIgSIASAIIgHASgAiJAQQAFgKAFgGIARAJIgKARgAhzgSIAMgQIAQAMIgMAPgAhagyIAOgPIAPAOIgOAOgAg9hPQAIgIAHgFIANAPIgPANgAgdhpIARgLIAKARIgPAKIAAAAgAAEh/IATgJIAIASIgRAJgAApiRIAUgHIAGASIgSAIgABRifIAUgFIAEAUIgTAEgAB5ioIAUgCIACATIgTADgACiisIAUgBIAAAUIgTABg");
	this.shape_297.setTransform(410.05,53.05);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#101828").s().p("AgJA4IAAhvIATAAIAABvg");
	this.shape_298.setTransform(392.8,77.625);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#101828").s().p("AgJBuIAAgUIATAAIAAAUgAgJBGIAAgUIATAAIAAAUgAgJAeIAAgUIATAAIAAAUgAgJgJIAAgUIATAAIAAAUgAgJgxIAAgUIATAAIAAAUgAgJhZIAAgUIATAAIAAAUg");
	this.shape_299.setTransform(268.75,160.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10.6,15.7,577.6,270.8);


(lib.Unlimitedtemplatesarrowsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("Ap+KZQAAn3FflqQFdlqH1gUIg2g2IAdgdIBlBlIhpBpIgcgcIA3g2QnkATlQFfQlTFeAAHmg");
	this.shape.setTransform(74.9,69.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("A1PVQMAAAgqfMAqfAAAMAAAAqfg");
	this.shape_1.setTransform(136,136);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,272,272);


(lib.Submitinspectionarrowsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AnKHmQAAljD2kCQDzkBFggSIg2g2IAdgdIBlBmIhpBoIgcgcIA3g3QlPAUjnD1QjpD1AAFSg");
	this.shape.setTransform(47.9,50.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AuNPeIAA+7IcbAAIAAe7g");
	this.shape_1.setTransform(91,99);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182,198);


(lib.Siteplansarrowsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C4E3").s().p("AngGeQFOAADyjlQDyjlAUlMIg3A4IgcgdIBphoIBlBkIgdAdIg2g2QgSFdj+DxQj+DzlgAAg");
	this.shape.setTransform(146,140.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AvTPUIAA+nIenAAIAAeng");
	this.shape_1.setTransform(98,98);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,196,196);


(lib.Photos03svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AgjB0QgIAAgCgIIgKhGQAAgEADgEQADgEAEAAIAjAAIAAgKIgPABQgmAAgYgXQgQgQgGgVQgHgVAFgWQABgGAGgCQAWgEAVAHQAWAGAPAQQAQAQAHAXIABAAQAAgkAZgXQAQgQAVgGQAVgHAWAEQAGACABAGQAFAWgHAVQgGAVgQAQQgYAYgmAAIgRgCIAAAeIAkAAQAEAAAEAEQACAEAAAEIgKBGQgBAIgJAAgAgaBgIA0AAIAHgyIhCAAgAhdhLQgDAgAXAXQAVAUAigDQACgfgWgVQgUgUgcAAIgHAAgAAnhLQgWAVACAfQAiADAVgUQAXgXgDggIgHAAQgcAAgUAUg");
	this.shape.setTransform(47.95,54.0476,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("AguAtQgDgSAGgSQAGgSANgNQAOgPATgFQASgGATAEQAEATgGATQgFASgPAOQgNANgTAFQgKADgLAAIgRgCg");
	this.shape_1.setTransform(59.2302,42.0847,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00C4E3").s().p("AAJAsQgTgFgNgNQgOgOgGgSQgGgTAEgTQATgEATAGQASAFAOAPQANANAGASQAGASgDASIgRACQgLAAgKgDg");
	this.shape_2.setTransform(36.6698,46.0847,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006D94").s().p("AgiAjIgKhFIBaAAIgKBFg");
	this.shape_3.setTransform(47.9,68.3,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#101828").s().p("AjSCeIAAk7IGlAAIAAE7gAi+CKIF9AAIAAkTIl9AAg");
	this.shape_4.setTransform(47.95,54.05,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AjcCoIAAlPIG5AAIAAFPg");
	this.shape_5.setTransform(45.95,56.05,2,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0)").s().p("AovHMIAAuXIRfAAIAAOXg");
	this.shape_6.setTransform(56,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,112,92);


(lib.Photos02svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AB4BUIAAhEIjvAAIAABEIgUAAIAAhOIABgFIAohPQACgFAHAAICzAAQAHAAACAFIAoBPIABAFIAABOgABygDIgeg8IinAAIgeA8IDjAAg");
	this.shape.setTransform(55.95,48.05,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00C4E3").s().p("AiBAoIAohPICzAAIAoBPg");
	this.shape_1.setTransform(55.95,41.2,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#101828").s().p("AjSCeIAAk7IGlAAIAAE7gAi+CKIF9AAIAAkTIl9AAg");
	this.shape_2.setTransform(55.95,46.05,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AjcCoIAAlPIG5AAIAAFPg");
	this.shape_3.setTransform(53.95,48.05,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0)").s().p("AovHMIAAuXIRfAAIAAOXg");
	this.shape_4.setTransform(56,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,112,92);


(lib.Photos01svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Animated_elements
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AA3BtIAAhEIhtAAIAABFIgUAAIAAhPIABgEIATglIAAhZQAAgEADgDQADgDAEAAIBZAAQAEAAADADQADADAAAEIAABZIATAlIABAEIAABPgAAxAVIgKgUIhNAAIgKAUIBhAAgAgigSIBFAAIAAhHIhFAAg");
	this.shape.setTransform(65.15,38.4,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006D94").s().p("AhAAUIAUgnIBZAAIAUAng");
	this.shape_1.setTransform(65.15,40.6,2,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#006D94").s().p("AgsAtIAAhaIBZAAIAABag");
	this.shape_2.setTransform(65.15,27.5,2,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#101828").s().p("AjSCeIAAk7IGlAAIAAE7gAi+CKIF9AAIAAkTIl9AAg");
	this.shape_3.setTransform(63.95,38.05,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjcCoIAAlPIG5AAIAAFPg");
	this.shape_4.setTransform(61.95,40.05,2,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0)").s().p("AovHMIAAuXIRfAAIAAOXg");
	this.shape_5.setTransform(56,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,112,92);


(lib.Wifionlinetext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#101828").s().p("AovA/QgPgIgJgPQgJgPAAgSQAAgSAJgPQAJgPAPgIQARgIATAAQATAAAQAIQAQAIAJAPQAJAPAAASQAAASgJAPQgJAPgQAIQgQAJgTAAQgTAAgRgJgAofgbQgJAFgGAJQgEAJAAALQAAALAEAKQAGAJAJAFQAJAFALAAQALAAAJgFQAJgFAFgJQAGgKAAgLQAAgLgGgJQgFgJgJgFQgJgGgLAAQgLAAgJAGgAIFBBQgMgHgHgLQgHgLAAgPQAAgOAHgKQAGgMAMgGQAMgHAPAAQANAAAMAHQALAGAIALQAGALAAAPIgBAHIhJAAQACAJAHAFQAHAGALAAQAJAAAFgDQAGgCAFgFIAPARQgNAPgbAAQgRAAgMgGgAI2ANQgBgJgGgFQgHgFgJAAQgKAAgHAFQgGAEgCAKIAwAAIAAAAgAGHBBQgMgGgGgLQgGgMgBgPQABgPAGgKQAGgLAMgGQALgHANAAQATAAAKAMIAAgvIAcAAIAACFIgbAAIAAgLQgKAMgUAAQgNAAgLgGgAGSACQgHAHAAAMQAAANAHAHQAHAHALAAQAKAAAHgHQAIgHAAgNQAAgMgIgHQgHgGgKAAQgLAAgHAGgAESBBQgMgHgGgLQgHgLAAgPQAAgOAHgKQAGgMAMgGQANgHAPAAQAPAAAMAHQANAGAGAMQAHAKAAAOQAAAPgHALQgGALgNAHQgMAGgPAAQgPAAgNgGgAEcACQgHAHAAAMQAAANAHAHQAHAHALAAQALAAAHgHQAHgHAAgNQAAgMgHgHQgHgGgLAAQgLAAgHAGgAg7BBQgNgHgHgLQgGgLAAgPQAAgOAGgKQAHgMAMgGQAMgHAOAAQAOAAALAHQALAGAHALQAGALAAAPIAAAHIhJAAQACAJAIAFQAHAGALAAQAIAAAGgDQAFgCAGgFIANARQgMAPgbAAQgQAAgMgGgAgKANQgCgJgGgFQgHgFgJAAQgKAAgGAFQgGAEgCAKIAwAAIAAAAgADJBGIAAhLIglA9IgOAAIgkg7IAABJIgcAAIAAh9IAZAAIAvBNIAuhNIAYAAIABB9gAiDBGIAAgzQAAgMgGgGQgFgEgJAAQgLAAgGAFQgGAHgBANIAAAwIgbAAIAAhgIAbAAIAAALQAFgGAIgDQAJgEAJAAQATAAALALQAKALABAUIAAA4gAkABGIAAhgIAbAAIAABggAk2BGIAAiFIAbAAIAACFgAlsBGIAAgzQABgMgGgGQgEgEgKAAQgLAAgGAFQgGAHgBANIAAAwIgcAAIAAhgIAbAAIAAALQAGgGAIgDQAJgEAKAAQARAAAMALQALALgBAUIAAA4gAj/gsQgFgFAAgGQAAgHAFgEQAFgFAHAAQAIAAAFAEQAFAFAAAGQAAAHgFAFQgFAEgIAAQgHAAgFgEg");
	this.shape.setTransform(0,6.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Cover
	this.instance = new lib.Cover("synched",0);
	this.instance.setTransform(0,8.45,6.0085,1.9475,0,0,0,0,6.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,-5,140,26);


(lib.Wifi = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Band_large
	this.instance = new lib.Wifi04svg("synched",0);
	this.instance.setTransform(46,28,1,1,0,0,0,46,28);
	this.instance.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(149).to({startPosition:0},0).to({alpha:1},5).to({startPosition:0},15).to({alpha:0.1992},1).to({startPosition:0},39).to({alpha:1},5).to({startPosition:0},15).to({alpha:0.1992},1).to({startPosition:0},39).to({alpha:1},5).to({startPosition:0},20).to({alpha:0.1992},4).wait(1));

	// Band_medium
	this.instance_1 = new lib.Wifi03svg("synched",0);
	this.instance_1.setTransform(46,28,1,1,0,0,0,46,28);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(134).to({startPosition:0},0).to({alpha:1},5).to({startPosition:0},30).to({alpha:0.1992},1).to({startPosition:0},24).to({alpha:1},5).to({startPosition:0},30).to({alpha:0.1992},1).to({startPosition:0},24).to({alpha:1},5).to({startPosition:0},35).to({alpha:0.1992},4).wait(1));

	// Band_small
	this.instance_2 = new lib.Wifi02svg("synched",0);
	this.instance_2.setTransform(46,28,1,1,0,0,0,46,28);
	this.instance_2.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(119).to({startPosition:0},0).to({alpha:1},5).to({startPosition:0},45).to({alpha:0.1992},1).to({startPosition:0},9).to({alpha:1},5).to({startPosition:0},45).to({alpha:0.1992},1).to({startPosition:0},9).to({alpha:1},5).to({startPosition:0},50).to({alpha:0.1992},4).wait(1));

	// Cover
	this.instance_3 = new lib.Cover("synched",0);
	this.instance_3.setTransform(34.5,47.3,0.6867,1.1985,0,0,0,0,6.7);
	this.instance_3.alpha = 0.8008;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(104).to({startPosition:0},0).to({alpha:0},5).to({startPosition:0},185).to({alpha:0.8008},4).wait(1));

	// Online_label
	this.instance_4 = new lib.Wifionlinetext("synched",0);
	this.instance_4.setTransform(35.8,70.6,1,1,0,0,0,0,7.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(104).to({_off:false},0).to({alpha:1},5).to({startPosition:0},185).to({alpha:0},4).wait(1));

	// Cover_cross
	this.instance_5 = new lib.Cover("synched",0);
	this.instance_5.setTransform(77.1,42.05,1.2875,2.2472,0,0,0,0.1,6.7);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(104).to({_off:false},0).to({alpha:1},5).to({startPosition:0},185).to({alpha:0},4).wait(1));

	// Background
	this.instance_6 = new lib.Wifi01svg("synched",0);
	this.instance_6.setTransform(46,28,1,1,0,0,0,46,28);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(299));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.2,0,140,84.4);


(lib.Uploadproperties = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Desktop
	this.instance = new lib.Uploadpropertiesdesktopsvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,66,56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AprFKIAAqTITXAAIAAKTg");
	mask.setTransform(0.025,-17.25);

	// Logo
	this.instance_1 = new lib.Uploadpropertieslogosvg("synched",0);
	this.instance_1.setTransform(0,0,1,1,0,0,0,66,56);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({startPosition:0},0).to({y:-60,alpha:0},10,cjs.Ease.cubicIn).to({y:60},280).to({y:0,alpha:1},10,cjs.Ease.cubicOut).wait(120));

	// Left
	this.instance_2 = new lib.Uploadpropertiesleftsvg("synched",0);
	this.instance_2.setTransform(0,60,1,1,0,0,0,66,56);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(44).to({_off:false},0).to({y:0,alpha:1},10,cjs.Ease.cubicOut).to({startPosition:0},245).to({y:-60,alpha:0},10,cjs.Ease.cubicOut).wait(140));

	// Center
	this.instance_3 = new lib.Uploadpropertiescentersvg("synched",0);
	this.instance_3.setTransform(0,60,1,1,0,0,0,66,56);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({y:0,alpha:1},10,cjs.Ease.cubicOut).to({startPosition:0},255).to({y:-60,alpha:0},10,cjs.Ease.cubicOut).wait(135));

	// Right
	this.instance_4 = new lib.Uploadpropertiesrightsvg("synched",0);
	this.instance_4.setTransform(0,60,1,1,0,0,0,66,56);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(49).to({_off:false},0).to({y:0,alpha:1},10,cjs.Ease.cubicOut).to({startPosition:0},250).to({y:-60,alpha:0},10,cjs.Ease.cubicIn).wait(130));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66,-56,132,112);


(lib.Unlimitedtemplates = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Template_01
	this.instance = new lib.Unlimitedtemplates01svg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,66,56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({startPosition:0},0).to({x:8,y:-8,alpha:0},10).wait(230));

	// Template_02
	this.instance_1 = new lib.Unlimitedtemplates02svg("synched",0);
	this.instance_1.setTransform(0,0,1,1,0,0,0,66,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:0},0).to({x:8,y:-8},10).to({startPosition:0},20).to({x:16,y:-16,alpha:0},10).wait(200));

	// Template_03
	this.instance_2 = new lib.Unlimitedtemplates03svg("synched",0);
	this.instance_2.setTransform(0,0,1,1,0,0,0,66,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(89).to({startPosition:0},0).to({x:8,y:-8},10).to({startPosition:0},20).to({x:16,y:-16},10).to({startPosition:0},20).to({x:24,y:-24,alpha:0},10).wait(170));

	// Template_01
	this.instance_3 = new lib.Unlimitedtemplates01svg("synched",0);
	this.instance_3.setTransform(-24,24,1,1,0,0,0,66,56);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(89).to({_off:false},0).to({x:-16,y:16,alpha:1},10).to({startPosition:0},20).to({x:-8,y:8},10).to({startPosition:0},20).to({x:0,y:0},10).wait(170));

	// Template_02
	this.instance_4 = new lib.Unlimitedtemplates03svg("synched",0);
	this.instance_4.setTransform(-8,8,1,1,0,0,0,66,56);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(119).to({_off:false},0).to({x:0,y:0,alpha:1},10).to({startPosition:0},20).to({x:8,y:-8},10).wait(170));

	// Template_03
	this.instance_5 = new lib.Unlimitedtemplates03svg("synched",0);
	this.instance_5.setTransform(-8,8,1,1,0,0,0,66,56);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(149).to({_off:false},0).to({x:0,y:0,alpha:1},10).wait(170));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-80,180,160);


(lib.Submitinspection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Click
	this.instance = new lib.Submitinspectionclicksvg("synched",0);
	this.instance.setTransform(36,36,1,1,0,0,0,36,36);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(99).to({_off:false},0).to({_off:true},6).wait(44));

	// Cursor
	this.instance_1 = new lib.Submitinspectioncursorsvg("synched",0);
	this.instance_1.setTransform(76,76,1,1,0,0,0,36,36);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({x:36,y:36,alpha:1},35,cjs.Ease.cubicOut).wait(4).to({startPosition:0},0).wait(1).to({scaleX:0.9444,scaleY:0.9444,x:34,y:34},0).wait(6).to({scaleX:1,scaleY:1,x:36,y:36},0).wait(29).to({startPosition:0},0).to({alpha:0},14).wait(1));

	// Button
	this.instance_2 = new lib.Submitinspectionbuttonsvg("synched",0);
	this.instance_2.setTransform(36,36,1,1,0,0,0,36,36);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(149));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,112,112);


(lib.Realtimeupdates = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrows
	this.instance = new lib.Realtimeupdatessvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,21,21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({rotation:2.4324,x:0.05,y:0.05},0).wait(1).to({rotation:4.8649,x:0,y:0},0).wait(1).to({rotation:7.2973,x:0.05,y:0.05},0).wait(1).to({rotation:9.7297},0).wait(1).to({rotation:12.1622,y:0},0).wait(1).to({rotation:14.5946,x:0},0).wait(1).to({rotation:17.027,x:0.05,y:0.05},0).wait(1).to({rotation:19.4595,x:0},0).wait(1).to({rotation:21.8919},0).wait(1).to({rotation:24.3243,x:0.05},0).wait(1).to({rotation:26.7568,y:0},0).wait(1).to({rotation:29.1892,y:0.05},0).wait(1).to({rotation:31.6216},0).wait(1).to({rotation:34.0541,y:0},0).wait(1).to({rotation:36.4865,y:0.05},0).wait(1).to({rotation:38.9189},0).wait(1).to({rotation:41.3514,y:0},0).wait(1).to({rotation:43.7838,x:0,y:0.05},0).wait(1).to({rotation:46.2162},0).wait(1).to({rotation:48.6486,x:-0.05,y:0},0).wait(1).to({rotation:51.0811,y:0.05},0).wait(1).to({rotation:53.5135},0).wait(1).to({rotation:55.9459,y:0},0).wait(1).to({rotation:58.3784,y:0.05},0).wait(1).to({rotation:60.8108},0).wait(1).to({rotation:63.2432,y:0},0).wait(1).to({rotation:65.6757,y:0.05},0).wait(1).to({rotation:68.1081,x:0},0).wait(1).to({rotation:70.5405},0).wait(1).to({rotation:72.973,x:-0.05},0).wait(1).to({rotation:75.4054,x:0,y:0},0).wait(1).to({rotation:77.8378,x:-0.05},0).wait(1).to({rotation:80.2703,y:0.05},0).wait(1).to({rotation:82.7027},0).wait(1).to({rotation:85.1351,x:0,y:0},0).wait(1).to({rotation:87.5676,x:-0.05,y:0.05},0).wait(1).to({rotation:90,x:0,y:0},0).wait(1).to({rotation:92.4324,x:-0.05,y:0.05},0).wait(1).to({rotation:94.8649,x:0,y:0},0).wait(1).to({rotation:97.2973,x:-0.05,y:0.05},0).wait(1).to({rotation:99.7297},0).wait(1).to({rotation:102.1622,x:0},0).wait(1).to({rotation:104.5946,y:0},0).wait(1).to({rotation:107.027,x:-0.05,y:0.05},0).wait(1).to({rotation:109.4595,y:0},0).wait(1).to({rotation:111.8919},0).wait(1).to({rotation:114.3243,y:0.05},0).wait(1).to({rotation:116.7568,x:0},0).wait(1).to({rotation:119.1892,x:-0.05},0).wait(1).to({rotation:121.6216},0).wait(1).to({rotation:124.0541,x:0},0).wait(1).to({rotation:126.4865,x:-0.05},0).wait(1).to({rotation:128.9189},0).wait(1).to({rotation:131.3514,x:0},0).wait(1).to({rotation:133.7838,x:-0.05,y:0},0).wait(1).to({rotation:136.2162},0).wait(1).to({rotation:138.6486,x:0,y:-0.05},0).wait(1).to({rotation:141.0811,x:-0.05},0).wait(1).to({rotation:143.5135},0).wait(1).to({rotation:145.9459,x:0},0).wait(1).to({rotation:148.3784,x:-0.05},0).wait(1).to({rotation:150.8108},0).wait(1).to({rotation:153.2432,x:0},0).wait(1).to({rotation:155.6757,x:-0.05},0).wait(1).to({rotation:158.1081,y:0},0).wait(1).to({rotation:160.5405},0).wait(1).to({rotation:162.973,y:-0.05},0).wait(1).to({rotation:165.4054,x:0,y:0},0).wait(1).to({rotation:167.8378,y:-0.05},0).wait(1).to({rotation:170.2703,x:-0.05},0).wait(1).to({rotation:172.7027},0).wait(1).to({rotation:175.1351,x:0,y:0},0).wait(1).to({rotation:177.5676,x:-0.05,y:-0.05},0).wait(1).to({rotation:180,x:0,y:0},0).wait(1).to({rotation:182.4324,x:-0.05,y:-0.05},0).wait(1).to({rotation:184.8649,x:0,y:0},0).wait(1).to({rotation:187.2973,x:-0.05,y:-0.05},0).wait(1).to({rotation:189.7297},0).wait(1).to({rotation:192.1622,y:0},0).wait(1).to({rotation:194.5946,x:0},0).wait(1).to({rotation:197.027,x:-0.05,y:-0.05},0).wait(1).to({rotation:199.4595,x:0},0).wait(1).to({rotation:201.8919},0).wait(1).to({rotation:204.3243,x:-0.05},0).wait(1).to({rotation:206.7568,y:0},0).wait(1).to({rotation:209.1892,y:-0.05},0).wait(1).to({rotation:211.6216},0).wait(1).to({rotation:214.0541,y:0},0).wait(1).to({rotation:216.4865,y:-0.05},0).wait(1).to({rotation:218.9189},0).wait(1).to({rotation:221.3514,y:0},0).wait(1).to({rotation:223.7838,x:0,y:-0.05},0).wait(1).to({rotation:226.2162},0).wait(1).to({rotation:228.6486,x:0.05,y:0},0).wait(1).to({rotation:231.0811,y:-0.05},0).wait(1).to({rotation:233.5135},0).wait(1).to({rotation:235.9459,y:0},0).wait(1).to({rotation:238.3784,y:-0.05},0).wait(1).to({rotation:240.8108},0).wait(1).to({rotation:243.2432,y:0},0).wait(1).to({rotation:245.6757,y:-0.05},0).wait(1).to({rotation:248.1081,x:0},0).wait(1).to({rotation:250.5405},0).wait(1).to({rotation:252.973,x:0.05},0).wait(1).to({rotation:255.4054,x:0,y:0},0).wait(1).to({rotation:257.8378,x:0.05},0).wait(1).to({rotation:260.2703,y:-0.05},0).wait(1).to({rotation:262.7027},0).wait(1).to({rotation:265.1351,x:0,y:0},0).wait(1).to({rotation:267.5676,x:0.05,y:-0.05},0).wait(1).to({rotation:270,x:0,y:0},0).wait(1).to({rotation:272.4324,x:0.05,y:-0.05},0).wait(1).to({rotation:274.8649,x:0,y:0},0).wait(1).to({rotation:277.2973,x:0.05,y:-0.05},0).wait(1).to({rotation:279.7297},0).wait(1).to({rotation:282.1622,x:0},0).wait(1).to({rotation:284.5946,y:0},0).wait(1).to({rotation:287.027,x:0.05,y:-0.05},0).wait(1).to({rotation:289.4595,y:0},0).wait(1).to({rotation:291.8919},0).wait(1).to({rotation:294.3243,y:-0.05},0).wait(1).to({rotation:296.7568,x:0},0).wait(1).to({rotation:299.1892,x:0.05},0).wait(1).to({rotation:301.6216},0).wait(1).to({rotation:304.0541,x:0},0).wait(1).to({rotation:306.4865,x:0.05},0).wait(1).to({rotation:308.9189},0).wait(1).to({rotation:311.3514,x:0},0).wait(1).to({rotation:313.7838,x:0.05,y:0},0).wait(1).to({rotation:316.2162},0).wait(1).to({rotation:318.6486,x:0,y:0.05},0).wait(1).to({rotation:321.0811,x:0.05},0).wait(1).to({rotation:323.5135},0).wait(1).to({rotation:325.9459,x:0},0).wait(1).to({rotation:328.3784,x:0.05},0).wait(1).to({rotation:330.8108},0).wait(1).to({rotation:333.2432,x:0},0).wait(1).to({rotation:335.6757,x:0.05},0).wait(1).to({rotation:338.1081,y:0},0).wait(1).to({rotation:340.5405},0).wait(1).to({rotation:342.973,y:0.05},0).wait(1).to({rotation:345.4054,x:0,y:0},0).wait(1).to({rotation:347.8378,y:0.05},0).wait(1).to({rotation:350.2703,x:0.05},0).wait(1).to({rotation:352.7027},0).wait(1).to({rotation:355.1351,x:0,y:0},0).wait(1).to({rotation:357.5676,x:0.05,y:0.05},0).wait(1).to({rotation:360,x:0,y:0},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.7,-29.7,59.5,59.5);


(lib.Managementreports = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Left
	this.instance = new lib.Reportsleftsvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,27,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(119).to({startPosition:0},0).to({alpha:0},5).wait(25).to({y:40},0).to({y:0,alpha:1},5,cjs.Ease.quadOut).to({startPosition:0},235).wait(1));

	// Center
	this.instance_1 = new lib.Reportscentersvg("synched",0);
	this.instance_1.setTransform(56,0,1,1,0,0,0,27,35);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(119).to({startPosition:0},0).to({alpha:0},5).wait(35).to({x:0},0).to({x:56,alpha:1},5,cjs.Ease.quadOut).to({startPosition:0},225).wait(1));

	// Right
	this.instance_2 = new lib.Reportsrightsvg("synched",0);
	this.instance_2.setTransform(112,0,1,1,0,0,0,27,35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(119).to({startPosition:0},0).to({alpha:0},5).wait(45).to({x:56},0).to({x:112,alpha:1},5,cjs.Ease.quadOut).to({startPosition:0},215).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-35,166,110);


(lib.Inspectionsuploaded = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Desktop
	this.instance = new lib.Inspectionsuploadeddesktopsvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,66,56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(350));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AphFeIAAq7ITDAAIAAK7g");
	mask.setTransform(0,-16);

	// Logo
	this.instance_1 = new lib.Inspectionsuploadedlogosvg("synched",0);
	this.instance_1.setTransform(0,0,1,1,0,0,0,66,56);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(209).to({startPosition:0},0).to({y:55,alpha:0},10,cjs.Ease.cubicIn).to({y:-52.5},120).to({y:0,alpha:1},10,cjs.Ease.cubicOut).wait(1));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AphFeIAAq7ITDAAIAAK7g");
	mask_1.setTransform(0,-16);

	// Document
	this.instance_2 = new lib.Inspectionsuploadeddocsvg("synched",0);
	this.instance_2.setTransform(0,-62.5,1,1,0,0,0,66,56);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(219).to({_off:false},0).to({y:0,alpha:1},10,cjs.Ease.cubicOut).to({startPosition:0},100).to({y:60,alpha:0},10,cjs.Ease.cubicIn).to({_off:true},1).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66,-56,132,112);


(lib.Conductinspectionmov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Static
	this.instance = new lib.Conductinspectionsvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,94,46);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(419));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjfEMIAAoXIG/AAIAAIXg");
	mask.setTransform(2.775,3.85);

	// Logo
	this.instance_1 = new lib.Conductinspectionlogosvg("synched",0);
	this.instance_1.setTransform(0,0,1,1,0,0,0,94,46);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({startPosition:0},0).to({y:35,alpha:0},10,cjs.Ease.cubicIn).to({y:-35},290).to({y:0,alpha:1},10,cjs.Ease.cubicOut).wait(50));

	// Cover_cross_middle
	this.instance_2 = new lib.Cover("synched",0);
	this.instance_2.setTransform(-8.1,3.95,1,1,0,0,0,0,6.7);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(89).to({_off:false},0).to({_off:true},60).wait(270));

	// Cover_tick_bottom
	this.instance_3 = new lib.Cover("synched",0);
	this.instance_3.setTransform(-8.1,17.7,1,1,0,0,0,0,6.7);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(89).to({_off:false},0).to({_off:true},120).wait(210));

	// Cover_line_top
	this.instance_4 = new lib.Cover("synched",0);
	this.instance_4.setTransform(15.65,-9.8,1,1,0,0,0,0,6.7);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(89).to({_off:false},0).wait(15).to({startPosition:0},0).to({x:33.15},14).to({_off:true},152).wait(149));

	// Cover_line_middle
	this.instance_5 = new lib.Cover("synched",0);
	this.instance_5.setTransform(15.65,3.95,1,1,0,0,0,0,6.7);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(89).to({_off:false},0).wait(75).to({startPosition:0},0).to({x:33.15},14).to({_off:true},92).wait(149));

	// Cover_line_bottom
	this.instance_6 = new lib.Cover("synched",0);
	this.instance_6.setTransform(15.65,17.7,1,1,0,0,0,0,6.7);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(89).to({_off:false},0).wait(135).to({startPosition:0},0).to({x:33.15},15).to({_off:true},31).wait(149));

	// Form
	this.instance_7 = new lib.Conductinspectionformsvg("synched",0);
	this.instance_7.setTransform(0,0,1,1,0,0,0,94,46);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(89).to({_off:false},0).wait(239).to({startPosition:0},0).to({alpha:0},30).to({_off:true},1).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94,-46,188,92);


(lib.Cog = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Cog
	this.instance = new lib.Cogsvg("synched",0);
	this.instance.setTransform(25.9,25.9,1,1,0,0,0,25.9,25.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:90,x:25.85,y:25.95,startPosition:29},59).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-1,54,54);


(lib.Unlimitedtemplatesarrowmov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsfLuIAA3bIY/AAIAAXbg");
	mask.setTransform(-77,-75.1);

	// Arrow2
	this.instance = new lib.Unlimitedtemplatesarrowsvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,136,136);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(149).to({startPosition:0},0).to({rotation:90},15,cjs.Ease.quadOut).to({_off:true},1).wait(304));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AsfLuIAA3bIY/AAIAAXbg");
	mask_1.setTransform(-77,-75.1);

	// Arrow1
	this.instance_1 = new lib.Unlimitedtemplatesarrowsvg("synched",0);
	this.instance_1.setTransform(0,0,1,1,-90,0,0,136,136);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(165).to({_off:false},0).to({rotation:0},15,cjs.Ease.quadOut).wait(289));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-150.1,160,150);


(lib.Submitinspectionarrowmov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoMINIAAwZIQZAAIAAQZg");
	mask.setTransform(-47.5,-52.5);

	// Arrow2
	this.instance = new lib.Submitinspectionarrowsvg("synched",0);
	this.instance.setTransform(0,0,1,1,-90,0,0,91,99);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(459).to({_off:false},0).to({rotation:0},10).wait(1));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AoMINIAAwZIQZAAIAAQZg");
	mask_1.setTransform(-47.5,-52.5);

	// Arrow1
	this.instance_1 = new lib.Submitinspectionarrowsvg("synched",0);
	this.instance_1.setTransform(0,0,1,1,0,0,0,91,99);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(449).to({startPosition:0},0).to({rotation:90},10).to({_off:true},1).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-100,-105,105,105);


(lib.Siteplanarrowmov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsfKKIAA0TIY/AAIAAUTg");
	mask.setTransform(80,62);

	// Arrow2
	this.instance = new lib.Siteplansarrowsvg("synched",0);
	this.instance.setTransform(0,0,1,1,90,0,0,98,98);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({rotation:0},10).wait(150));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AsfKKIAA0TIY/AAIAAUTg");
	mask_1.setTransform(80,62);

	// Arrow1
	this.instance_1 = new lib.Siteplansarrowsvg("synched",0);
	this.instance_1.setTransform(0,0,1,1,0,0,0,98,98);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(299).to({startPosition:0},0).to({rotation:-90},10).to({_off:true},1).wait(159));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-3,138.7,130);


(lib.Addphotos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Photo_01
	this.instance = new lib.Photos01svg("synched",0);
	this.instance.setTransform(0,1,1,1,0,0,0,56,46);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(209).to({startPosition:0},0).to({x:8,y:-7,alpha:0},10).wait(110));

	// Photo_02
	this.instance_1 = new lib.Photos02svg("synched",0);
	this.instance_1.setTransform(0,1,1,1,0,0,0,56,46);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(209).to({startPosition:0},0).to({x:8,y:-7},10).to({startPosition:0},20).to({x:16,y:-15,alpha:0},10).wait(80));

	// Photo_03
	this.instance_2 = new lib.Photos03svg("synched",0);
	this.instance_2.setTransform(0,1,1,1,0,0,0,56,46);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(209).to({startPosition:0},0).to({x:8,y:-7},10).to({startPosition:0},20).to({x:16,y:-15},10).to({startPosition:0},20).to({x:24,y:-23,alpha:0},10).wait(50));

	// Photo_01
	this.instance_3 = new lib.Photos01svg("synched",0);
	this.instance_3.setTransform(-24,25,1,1,0,0,0,56,46);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(209).to({_off:false},0).to({x:-16,y:17,alpha:1},10).to({startPosition:0},20).to({x:-8,y:9},10).to({startPosition:0},20).to({x:0,y:1},10).wait(50));

	// Photo_02
	this.instance_4 = new lib.Photos02svg("synched",0);
	this.instance_4.setTransform(-16,17,1,1,0,0,0,56,46);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(239).to({_off:false},0).to({x:-8,y:9,alpha:1},10).to({startPosition:0},20).to({x:0,y:1},10).wait(50));

	// Photo_03
	this.instance_5 = new lib.Photos03svg("synched",0);
	this.instance_5.setTransform(-8,9,1,1,0,0,0,56,46);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(269).to({_off:false},0).to({x:0,y:1,alpha:1},10).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-69,160,140);


// stage content:
(lib.Bermwood = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Conduct_inspection
	this.instance = new lib.Conductinspectionmov();
	this.instance.setTransform(534.4,199.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Unlimited_templates
	this.instance_1 = new lib.Unlimitedtemplates();
	this.instance_1.setTransform(315.15,263.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Add_photos
	this.instance_2 = new lib.Addphotos();
	this.instance_2.setTransform(528.65,380.85,1,1,0,0,0,0,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Upload_properties
	this.instance_3 = new lib.Uploadproperties();
	this.instance_3.setTransform(86.25,236.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Management_reports
	this.instance_4 = new lib.Managementreports();
	this.instance_4.setTransform(1100.25,233.05,1,1,0,0,0,60,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Inspections_uploaded
	this.instance_5 = new lib.Inspectionsuploaded();
	this.instance_5.setTransform(929.2,252.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Submit_inspection
	this.instance_6 = new lib.Submitinspection();
	this.instance_6.setTransform(786,209.05,1,1,0,0,0,36,36);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// Offline_mode
	this.instance_7 = new lib.Wifi();
	this.instance_7.setTransform(442.4,82.05,1,1,0,0,0,46,28);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// Real_time_updates
	this.instance_8 = new lib.Realtimeupdates();
	this.instance_8.setTransform(261.9,442.8,1.9999,1.9999,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// Cog
	this.instance_9 = new lib.Cog();
	this.instance_9.setTransform(858.25,130.05,1,1,0,0,0,25.9,25.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// Background
	this.instance_10 = new lib.Backgroundsvg("synched",0);
	this.instance_10.setTransform(300,150,2,2,0,0,0,150,75);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

	// Arrow_submit_inspection
	this.instance_11 = new lib.Submitinspectionarrowmov();
	this.instance_11.setTransform(852.65,140.55,1,1,0,0,0,-4.5,-3);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1));

	// Arrow_site_plans
	this.instance_12 = new lib.Siteplanarrowmov();
	this.instance_12.setTransform(748.15,514.15,1,1,0,0,0,31,14.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(1));

	// Arrow_unlimited_templates
	this.instance_13 = new lib.Unlimitedtemplatesarrowmov();
	this.instance_13.setTransform(431.2,137.55,1,1,0,0,0,3,-3);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(620.3,290.5,559,336.20000000000005);
// library properties:
lib.properties = {
	id: 'B8AB082719A446399121E091B09EECE2',
	width: 1200,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B8AB082719A446399121E091B09EECE2'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;